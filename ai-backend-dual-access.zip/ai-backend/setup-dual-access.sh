#!/bin/bash
# ═══════════════════════════════════════════════════════════
#  setup-dual-access.sh
#  One-command setup for BOTH public internet + LAN access.
#
#  What it does:
#    1. Asks for your public domain (optional)
#    2. Generates a self-signed cert for LAN access
#    3. Optionally gets a Let's Encrypt cert for your domain
#    4. Updates nginx.conf and .env with correct values
#    5. Opens Ubuntu firewall ports
#    6. Starts all services and runs migrations
#
#  Usage:
#    chmod +x setup-dual-access.sh
#    ./setup-dual-access.sh
# ═══════════════════════════════════════════════════════════

set -e

# ── Colors ────────────────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

info()    { echo -e "${BLUE}[INFO]${NC}    $1"; }
success() { echo -e "${GREEN}[OK]${NC}      $1"; }
warn()    { echo -e "${YELLOW}[WARN]${NC}    $1"; }
error()   { echo -e "${RED}[ERROR]${NC}   $1"; exit 1; }
section() { echo -e "\n${BOLD}${CYAN}══ $1 ══${NC}\n"; }

# ── Detect root (needed for ufw / certbot) ─────────────────────────────────────
if [ "$EUID" -ne 0 ]; then
    SUDO="sudo"
else
    SUDO=""
fi

# ── Sanity checks ─────────────────────────────────────────────────────────────
[ ! -f "docker-compose.yml" ] && error "Run from the ai-backend/ project root"
command -v docker &>/dev/null  || error "Docker not installed. See README.md Step 3."
command -v openssl &>/dev/null || { $SUDO apt-get install -y openssl; }

# ═════════════════════════════════════════════════════════════════════════════
section "Welcome to AI Backend Dual-Access Setup"
echo "  This will configure your API to be reachable from:"
echo "  • Any device on your LAN / WiFi (self-signed HTTPS)"
echo "  • The public internet via your domain (Let's Encrypt HTTPS)"
echo ""
# ═════════════════════════════════════════════════════════════════════════════

# ── Step 0: Detect network info ───────────────────────────────────────────────
LAN_IP=$(hostname -I | awk '{print $1}')
PUBLIC_IP=$(curl -s --max-time 5 https://api.ipify.org 2>/dev/null || echo "unknown")
info "LAN IP:    ${LAN_IP}"
info "Public IP: ${PUBLIC_IP}"

# ── Step 1: Get public domain (optional) ─────────────────────────────────────
echo ""
read -p "$(echo -e "${BOLD}Do you have a public domain pointing to this server? [y/N]:${NC} ")" HAS_DOMAIN
HAS_DOMAIN=${HAS_DOMAIN:-n}

PUBLIC_DOMAIN=""
ADMIN_EMAIL=""
USE_LETSENCRYPT=false

if [[ "$HAS_DOMAIN" =~ ^[Yy]$ ]]; then
    read -p "  Enter domain (e.g. api.myapp.com): " PUBLIC_DOMAIN
    read -p "  Enter admin email for Let's Encrypt: " ADMIN_EMAIL

    # Verify DNS resolves to this machine
    RESOLVED=$(dig +short "$PUBLIC_DOMAIN" 2>/dev/null | tail -1 || true)
    if [ "$RESOLVED" = "$PUBLIC_IP" ]; then
        success "DNS check passed: $PUBLIC_DOMAIN → $PUBLIC_IP"
        USE_LETSENCRYPT=true
    else
        warn "DNS check: $PUBLIC_DOMAIN resolves to '$RESOLVED', expected '$PUBLIC_IP'"
        warn "Continuing anyway — cert will fail if DNS is wrong."
        USE_LETSENCRYPT=true
    fi
fi

# ── Step 2: .env setup ────────────────────────────────────────────────────────
section "Environment Configuration"

if [ ! -f "backend/.env" ]; then
    cp backend/.env.example backend/.env
    info "Created backend/.env from .env.example"
fi

# Auto-generate SECRET_KEY if still default
if grep -q "your_super_secret_key" backend/.env; then
    NEW_KEY=$(openssl rand -hex 32)
    sed -i "s/your_super_secret_key_change_this_in_production_minimum_32_chars/$NEW_KEY/" backend/.env
    success "SECRET_KEY auto-generated"
fi

# Build CORS origins list
CORS_ORIGINS="https://${LAN_IP},http://${LAN_IP}:8080,https://localhost,http://localhost:3000"
if [ -n "$PUBLIC_DOMAIN" ]; then
    CORS_ORIGINS="${CORS_ORIGINS},https://${PUBLIC_DOMAIN}"
fi

# Update CORS_ORIGINS in .env
if grep -q "^CORS_ORIGINS=" backend/.env; then
    sed -i "s|^CORS_ORIGINS=.*|CORS_ORIGINS=${CORS_ORIGINS}|" backend/.env
else
    echo "CORS_ORIGINS=${CORS_ORIGINS}" >> backend/.env
fi
success "CORS_ORIGINS set: ${CORS_ORIGINS}"

# Check for AI API key
if grep -q "sk-your-openai-api-key" backend/.env && grep -q "your-gemini-api-key" backend/.env; then
    warn "⚠  No AI API key detected in backend/.env"
    warn "   Edit backend/.env and set OPENAI_API_KEY or GEMINI_API_KEY before using chat."
fi

# ── Step 3: Generate self-signed SSL cert for LAN ─────────────────────────────
section "SSL Certificate — LAN (Self-Signed)"
mkdir -p nginx/ssl

openssl req -x509 \
    -newkey rsa:4096 \
    -keyout nginx/ssl/key.pem \
    -out  nginx/ssl/cert.pem \
    -days 730 \
    -nodes \
    -subj "/C=US/ST=Dev/L=Local/O=AIBackend/CN=${LAN_IP}" \
    -addext "subjectAltName=IP:${LAN_IP},IP:127.0.0.1,DNS:localhost" \
    2>/dev/null

chmod 600 nginx/ssl/key.pem
chmod 644 nginx/ssl/cert.pem
success "Self-signed cert created (valid 2 years for ${LAN_IP})"

# ── Step 4: Update nginx.conf for public domain ───────────────────────────────
section "Nginx Configuration"

if [ -n "$PUBLIC_DOMAIN" ]; then
    # Replace placeholder domain in nginx.conf
    sed -i "s|api.yourdomain.com|${PUBLIC_DOMAIN}|g" nginx/nginx.conf
    success "nginx.conf updated with domain: ${PUBLIC_DOMAIN}"
else
    # No public domain — comment out SERVER 3 (public HTTPS block)
    # The LAN block (SERVER 4, default_server) handles everything
    info "No public domain — nginx will use self-signed cert for all HTTPS connections"
    # Mark the Let's Encrypt cert lines as placeholders so nginx won't fail
    # by replacing the letsencrypt ssl_certificate lines with the self-signed ones
    sed -i 's|ssl_certificate     /etc/letsencrypt/live/.*|ssl_certificate     /etc/nginx/ssl/cert.pem;  # placeholder|' nginx/nginx.conf
    sed -i 's|ssl_certificate_key /etc/letsencrypt/live/.*|ssl_certificate_key /etc/nginx/ssl/key.pem;  # placeholder|' nginx/nginx.conf
    success "nginx.conf configured for LAN-only mode"
fi

# ── Step 5: Open firewall ports ───────────────────────────────────────────────
section "Firewall Configuration"

if command -v ufw &>/dev/null; then
    $SUDO ufw allow 80/tcp   comment "HTTP (nginx)"     2>/dev/null || true
    $SUDO ufw allow 443/tcp  comment "HTTPS (nginx)"    2>/dev/null || true
    $SUDO ufw allow 8080/tcp comment "LAN HTTP fallback" 2>/dev/null || true
    # Only allow SSH if not already configured (safety net)
    $SUDO ufw allow 22/tcp   comment "SSH"              2>/dev/null || true
    $SUDO ufw --force enable 2>/dev/null || true
    success "UFW firewall: ports 80, 443, 8080, 22 opened"
else
    warn "ufw not found — skip firewall config (iptables may need manual setup)"
fi

# ── Step 6: Get Let's Encrypt certificate ─────────────────────────────────────
if [ "$USE_LETSENCRYPT" = true ]; then
    section "SSL Certificate — Public Domain (Let's Encrypt)"

    if ! command -v certbot &>/dev/null; then
        info "Installing certbot..."
        $SUDO apt-get update -qq
        $SUDO apt-get install -y certbot
    fi

    info "Obtaining certificate for ${PUBLIC_DOMAIN}..."
    info "Port 80 must be open and DNS must resolve correctly."

    # Use standalone mode (temporarily binds port 80)
    # If nginx is running we need to stop it first
    docker compose stop nginx 2>/dev/null || true

    $SUDO certbot certonly \
        --standalone \
        --non-interactive \
        --agree-tos \
        --email "${ADMIN_EMAIL}" \
        -d "${PUBLIC_DOMAIN}" \
        --preferred-challenges http \
        && CERT_OK=true || CERT_OK=false

    if [ "$CERT_OK" = true ]; then
        success "Let's Encrypt certificate obtained for ${PUBLIC_DOMAIN}"
        # Set up cron auto-renewal + nginx reload
        (crontab -l 2>/dev/null; echo "0 3 * * * certbot renew --quiet --post-hook 'docker compose -f $(pwd)/docker-compose.yml exec nginx nginx -s reload'") | crontab -
        success "Auto-renewal cron job installed (runs daily at 3am)"
    else
        warn "Let's Encrypt certificate failed — continuing with self-signed cert for all connections"
        sed -i "s|ssl_certificate     /etc/letsencrypt/live/${PUBLIC_DOMAIN}/fullchain.pem;|ssl_certificate     /etc/nginx/ssl/cert.pem;|" nginx/nginx.conf
        sed -i "s|ssl_certificate_key /etc/letsencrypt/live/${PUBLIC_DOMAIN}/privkey.pem;|ssl_certificate_key /etc/nginx/ssl/key.pem;|" nginx/nginx.conf
    fi
fi

# ── Step 7: Build and start all services ─────────────────────────────────────
section "Starting Services"

info "Building Docker images..."
docker compose build --quiet

info "Starting postgres and redis..."
docker compose up -d postgres redis

info "Waiting for database to be ready..."
sleep 8

info "Running database migrations..."
docker compose run --rm migrate

info "Starting API and nginx..."
docker compose up -d api
sleep 10
docker compose up -d nginx certbot

# ── Step 8: Health check ──────────────────────────────────────────────────────
section "Health Check"

sleep 5
HTTP_STATUS=$(curl -sk -o /dev/null -w "%{http_code}" https://${LAN_IP}/api/v1/health 2>/dev/null || echo "000")

if [ "$HTTP_STATUS" = "200" ]; then
    success "Health check passed (HTTP ${HTTP_STATUS})"
else
    warn "Health check returned HTTP ${HTTP_STATUS} — services may still be starting"
    info "Check logs: docker compose logs -f api"
fi

# ── Final Summary ─────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}${GREEN}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${BOLD}${GREEN}║          ✅  Setup Complete!                          ║${NC}"
echo -e "${BOLD}${GREEN}╚═══════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  ${BOLD}LAN Access (any device on your network):${NC}"
echo -e "  🔒 HTTPS  →  ${CYAN}https://${LAN_IP}/docs${NC}       (SSL warning once)"
echo -e "  🔓 HTTP   →  ${CYAN}http://${LAN_IP}:8080/docs${NC}   (no SSL, fallback)"
echo ""

if [ -n "$PUBLIC_DOMAIN" ]; then
echo -e "  ${BOLD}Public Internet:${NC}"
echo -e "  🌍 HTTPS  →  ${CYAN}https://${PUBLIC_DOMAIN}/docs${NC}"
echo ""
fi

echo -e "  ${BOLD}Local (this machine):${NC}"
echo -e "  💻 HTTPS  →  ${CYAN}https://localhost/docs${NC}"
echo ""
echo -e "  ${BOLD}Default admin login:${NC}"
echo -e "     Email:    admin@example.com"
echo -e "     Password: Admin@123456"
echo -e "     ${YELLOW}(Change in backend/.env → FIRST_ADMIN_EMAIL / FIRST_ADMIN_PASSWORD)${NC}"
echo ""
echo -e "  ${BOLD}Useful commands:${NC}"
echo -e "     docker compose logs -f api     # watch logs"
echo -e "     docker compose ps              # service status"
echo -e "     docker compose down            # stop all"
echo ""

# Save access info to file for reference
cat > ACCESS_INFO.txt << ACCESS
AI Backend — Access Information
Generated: $(date)

LAN HTTPS:      https://${LAN_IP}/docs
LAN HTTP:       http://${LAN_IP}:8080/docs
Local:          https://localhost/docs
$([ -n "$PUBLIC_DOMAIN" ] && echo "Public HTTPS:   https://${PUBLIC_DOMAIN}/docs")

Default admin:
  Email:    $(grep FIRST_ADMIN_EMAIL backend/.env | cut -d= -f2)
  Password: $(grep FIRST_ADMIN_PASSWORD backend/.env | cut -d= -f2)
ACCESS

info "Access info saved to ACCESS_INFO.txt"
