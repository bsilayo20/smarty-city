# 🤖 AI Backend API — Complete Setup Guide

A production-ready FastAPI backend with JWT auth, AI chat (OpenAI/Gemini), Redis caching, and PostgreSQL.

---

## 📁 Project Structure

```
ai-backend/
├── docker-compose.yml          ← Orchestrates all services
├── .gitignore
└── backend/
    ├── Dockerfile
    ├── requirements.txt
    ├── alembic.ini              ← Migration config
    ├── .env.example             ← Copy this to .env
    ├── alembic/
    │   ├── env.py               ← Migration environment
    │   ├── script.py.mako       ← Migration template
    │   └── versions/
    │       └── 001_initial_migration.py
    ├── app/
    │   ├── main.py              ← FastAPI app factory + startup
    │   ├── api/v1/
    │   │   ├── router.py        ← Combines all route modules
    │   │   └── endpoints/
    │   │       ├── auth.py      ← Register, Login, Refresh, Me
    │   │       ├── users.py     ← Profile, Change Password
    │   │       ├── chat.py      ← AI Chat + Streaming + History
    │   │       ├── admin.py     ← Admin CRUD + Stats
    │   │       └── health.py    ← Health check
    │   ├── core/
    │   │   ├── config.py        ← Pydantic settings (reads .env)
    │   │   ├── security.py      ← JWT + bcrypt
    │   │   ├── dependencies.py  ← FastAPI Depends() helpers
    │   │   ├── exceptions.py    ← Custom exceptions + global handler
    │   │   └── logging.py       ← Structured JSON logging
    │   ├── models/              ← SQLAlchemy ORM models
    │   │   ├── user.py
    │   │   ├── chat.py
    │   │   └── api_usage.py
    │   ├── schemas/             ← Pydantic request/response schemas
    │   │   ├── user.py
    │   │   ├── chat.py
    │   │   └── common.py
    │   ├── services/            ← Business logic layer
    │   │   ├── auth_service.py
    │   │   ├── ai_service.py    ← OpenAI + Gemini + Redis cache
    │   │   ├── chat_service.py
    │   │   └── user_service.py
    │   ├── db/
    │   │   ├── base.py          ← SQLAlchemy DeclarativeBase
    │   │   ├── session.py       ← Async engine + session factory
    │   │   └── init_db.py       ← Seed first admin user
    │   └── middleware/
    │       └── logging_middleware.py
    └── tests/
        ├── conftest.py
        ├── test_auth.py
        └── test_health.py
```

---

## 🖥️ UBUNTU SETUP GUIDE (Step by Step)

### Step 1 — Update Your System

```bash
sudo apt update && sudo apt upgrade -y
```

### Step 2 — Install Python 3.11

```bash
# Add deadsnakes PPA for the latest Python versions
sudo apt install -y software-properties-common
sudo add-apt-repository ppa:deadsnakes/ppa -y
sudo apt update

# Install Python 3.11
sudo apt install -y python3.11 python3.11-venv python3.11-dev python3-pip

# Verify installation
python3.11 --version   # should print: Python 3.11.x
```

### Step 3 — Install Docker & Docker Compose

```bash
# Remove old versions
sudo apt remove -y docker docker-engine docker.io containerd runc

# Install prerequisites
sudo apt install -y ca-certificates curl gnupg lsb-release

# Add Docker's official GPG key
sudo mkdir -p /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg \
    | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg

# Add Docker repository
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
  https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" \
  | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# Install Docker Engine + Compose plugin
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin

# Allow your user to run Docker without sudo
sudo usermod -aG docker $USER
newgrp docker

# Verify Docker works
docker --version          # Docker version 24.x.x
docker compose version    # Docker Compose version v2.x.x
```

### Step 4 — Install PostgreSQL (for local development without Docker)

> Skip this step if you will ONLY use Docker.

```bash
sudo apt install -y postgresql postgresql-contrib

# Start and enable PostgreSQL service
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Create database and user
sudo -u postgres psql <<EOF
CREATE USER ai_user WITH PASSWORD 'your_strong_password_here';
CREATE DATABASE ai_backend_db OWNER ai_user;
GRANT ALL PRIVILEGES ON DATABASE ai_backend_db TO ai_user;
EOF

# Test the connection
psql -h localhost -U ai_user -d ai_backend_db
# Type \q to exit
```

### Step 5 — Clone / Download the Project

```bash
# If using Git:
git clone <your-repo-url> ai-backend
cd ai-backend

# Or if you have the files already:
cd ai-backend   # navigate to the project root
```

### Step 6 — Configure Environment Variables

```bash
# Copy the example file
cp backend/.env.example backend/.env

# Edit with your real values
nano backend/.env
```

**Critical values to set:**

```env
# Generate a secure secret key:
# Run: openssl rand -hex 32
SECRET_KEY=your_generated_secret_key_here

# Your AI API key (at least one required)
OPENAI_API_KEY=sk-...
# OR
GEMINI_API_KEY=...

# Database password (must match POSTGRES_PASSWORD in docker-compose.yml)
POSTGRES_PASSWORD=your_strong_password_here
```

---

## 🐳 RUNNING WITH DOCKER (Recommended)

### Start All Services

```bash
# From the project root (where docker-compose.yml is)
cd ai-backend

# Build and start everything in the background
docker compose up -d --build

# Watch the logs
docker compose logs -f api
```

### Run Database Migrations

```bash
# Run migrations (creates all tables)
docker compose run --rm migrate

# Verify migrations ran
docker compose exec postgres psql -U ai_user -d ai_backend_db -c "\dt"
```

### Verify Everything is Running

```bash
# Check service status
docker compose ps

# Test the health endpoint
curl http://localhost:8000/api/v1/health

# Open Swagger UI in your browser
# http://localhost:8000/docs
```

### Stop Everything

```bash
docker compose down          # stop containers (data preserved)
docker compose down -v       # stop + DELETE all data volumes
```

---

## 🐍 RUNNING WITHOUT DOCKER (Local Development)

### Step 1 — Create Virtual Environment

```bash
cd backend

# Create venv using Python 3.11
python3.11 -m venv .venv

# Activate it
source .venv/bin/activate

# Your prompt should now show (.venv)
```

### Step 2 — Install Dependencies

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

### Step 3 — Start Redis Locally

```bash
# Install Redis
sudo apt install -y redis-server
sudo systemctl start redis-server

# Test
redis-cli ping   # should print: PONG
```

### Step 4 — Update .env for Local Connections

```env
POSTGRES_HOST=localhost
REDIS_HOST=localhost
```

### Step 5 — Run Migrations

```bash
# From the backend/ directory
alembic upgrade head

# Check what migrations are pending
alembic current
alembic history
```

### Step 6 — Start the Server

```bash
# Development mode (auto-reload on file changes)
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload

# Production mode
uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 4
```

---

## 🧪 TESTING THE API

### Using Swagger UI

1. Open http://localhost:8000/docs
2. Click **POST /api/v1/auth/register** → Try it out → Register
3. Click **POST /api/v1/auth/login** → Get your token
4. Click the **Authorize** button (top right) → Enter `Bearer <your_token>`
5. Now all authenticated endpoints are unlocked

### Using curl

```bash
# 1. Register a user
curl -X POST http://localhost:8000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username":"johndoe","email":"john@example.com","password":"SecurePass1"}'

# 2. Login
TOKEN=$(curl -s -X POST http://localhost:8000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"john@example.com","password":"SecurePass1"}' \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['access_token'])")

echo "Token: $TOKEN"

# 3. Send a chat message
curl -X POST http://localhost:8000/api/v1/chat \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"prompt":"Explain what FastAPI is in 2 sentences."}'

# 4. Get chat history
curl http://localhost:8000/api/v1/chat/history \
  -H "Authorization: Bearer $TOKEN"

# 5. Admin stats (login as admin first)
ADMIN_TOKEN=$(curl -s -X POST http://localhost:8000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@example.com","password":"Admin@123456"}' \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['access_token'])")

curl http://localhost:8000/api/v1/admin/stats \
  -H "Authorization: Bearer $ADMIN_TOKEN"
```

### Running Automated Tests

```bash
cd backend

# Activate venv first
source .venv/bin/activate

# Install test dependencies
pip install pytest pytest-asyncio httpx aiosqlite

# Run all tests
pytest tests/ -v

# Run with coverage report
pytest tests/ -v --cov=app --cov-report=html
# Open htmlcov/index.html in browser
```

---

## 🔌 CONNECTING TO A FRONTEND

### CORS Configuration

Edit `backend/.env`:
```env
CORS_ORIGINS=http://localhost:3000,http://localhost:5173,https://yourdomain.com
```

### Frontend API Integration Example (JavaScript)

```javascript
const API_BASE = "http://localhost:8000/api/v1";

// Login and store token
async function login(email, password) {
  const res = await fetch(`${API_BASE}/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password }),
  });
  const data = await res.json();
  localStorage.setItem("access_token", data.access_token);
  localStorage.setItem("refresh_token", data.refresh_token);
  return data;
}

// Send a chat message
async function sendChat(prompt) {
  const token = localStorage.getItem("access_token");
  const res = await fetch(`${API_BASE}/chat`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${token}`,
    },
    body: JSON.stringify({ prompt }),
  });
  return await res.json();
}

// Stream chat response (Server-Sent Events)
function streamChat(prompt, onChunk) {
  const token = localStorage.getItem("access_token");

  fetch(`${API_BASE}/chat/stream`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${token}`,
    },
    body: JSON.stringify({ prompt, stream: true }),
  }).then(async (res) => {
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      const chunk = decoder.decode(value);
      const lines = chunk.split("\n").filter(l => l.startsWith("data: "));
      for (const line of lines) {
        const text = line.replace("data: ", "");
        if (text === "[DONE]") return;
        if (!text.startsWith("[ERROR]")) onChunk(text);
      }
    }
  });
}
```

### React + Axios Example

```javascript
import axios from "axios";

const api = axios.create({ baseURL: "http://localhost:8000/api/v1" });

// Attach token to every request automatically
api.interceptors.request.use((config) => {
  const token = localStorage.getItem("access_token");
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Auto-refresh token on 401
api.interceptors.response.use(
  (res) => res,
  async (error) => {
    if (error.response?.status === 401) {
      const refresh = localStorage.getItem("refresh_token");
      const { data } = await api.post("/auth/refresh", { refresh_token: refresh });
      localStorage.setItem("access_token", data.access_token);
      error.config.headers.Authorization = `Bearer ${data.access_token}`;
      return api.request(error.config);
    }
    return Promise.reject(error);
  }
);

export default api;
```

---

## 🐛 DEBUGGING COMMON ERRORS

### Error: `connection refused` to PostgreSQL

```bash
# Check if postgres container is running
docker compose ps

# Check postgres logs
docker compose logs postgres

# Make sure POSTGRES_HOST=postgres in .env (not localhost when using Docker)
```

### Error: `alembic: command not found`

```bash
# Make sure venv is activated
source .venv/bin/activate

# Or run via python -m
python -m alembic upgrade head
```

### Error: `ModuleNotFoundError`

```bash
# Make sure you're in the backend/ directory
cd backend
# And venv is active
source .venv/bin/activate
pip install -r requirements.txt
```

### Error: `JWT decode error`

```bash
# Make sure SECRET_KEY in .env is at least 32 characters
# Generate one with:
openssl rand -hex 32
```

### Error: `OpenAI API key invalid`

```bash
# Verify your key starts with sk-
echo $OPENAI_API_KEY

# Test directly
curl https://api.openai.com/v1/models \
  -H "Authorization: Bearer $OPENAI_API_KEY"
```

### Error: Redis connection refused

```bash
# Check if redis is running
docker compose ps redis

# Test redis connection
docker compose exec redis redis-cli ping
# Should respond: PONG
```

### Error: `422 Unprocessable Entity`

This means your request body didn't pass validation.
Check the `error.detail` array in the response — it tells you exactly which field failed.

### View All Logs

```bash
# All services
docker compose logs -f

# Just the API
docker compose logs -f api

# Last 100 lines
docker compose logs --tail=100 api
```

---

## 🔐 API ENDPOINTS REFERENCE

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/api/v1/health` | None | Health check |
| POST | `/api/v1/auth/register` | None | Create account |
| POST | `/api/v1/auth/login` | None | Get JWT tokens |
| POST | `/api/v1/auth/refresh` | None | Refresh tokens |
| GET | `/api/v1/auth/me` | User | Current user info |
| GET | `/api/v1/users/me` | User | User profile |
| PATCH | `/api/v1/users/me` | User | Update profile |
| POST | `/api/v1/users/me/change-password` | User | Change password |
| POST | `/api/v1/chat` | User | AI chat |
| POST | `/api/v1/chat/stream` | User | Streaming AI chat |
| GET | `/api/v1/chat/history` | User | Chat history |
| DELETE | `/api/v1/chat/{id}` | User | Delete message |
| GET | `/api/v1/admin/users` | Admin | List all users |
| DELETE | `/api/v1/admin/users/{id}` | Admin | Delete user |
| PATCH | `/api/v1/admin/users/{id}/toggle` | Admin | Activate/deactivate |
| GET | `/api/v1/admin/chats` | Admin | All chats |
| GET | `/api/v1/admin/stats` | Admin | Usage stats |

---

## ⚙️ ENVIRONMENT VARIABLES QUICK REFERENCE

| Variable | Required | Description |
|----------|----------|-------------|
| `SECRET_KEY` | ✅ | JWT signing key (min 32 chars) |
| `OPENAI_API_KEY` | ✅* | OpenAI API key |
| `GEMINI_API_KEY` | ✅* | Google Gemini API key |
| `POSTGRES_PASSWORD` | ✅ | Database password |
| `AI_PROVIDER` | No | `openai` (default) or `gemini` |
| `CORS_ORIGINS` | No | Comma-separated allowed origins |
| `DEBUG` | No | `false` in production |

*At least one AI provider key is required.

---

## 🚀 PRODUCTION CHECKLIST

- [ ] Set `DEBUG=false`
- [ ] Set `ENVIRONMENT=production`
- [ ] Use a strong `SECRET_KEY` (openssl rand -hex 32)
- [ ] Set a strong `POSTGRES_PASSWORD`
- [ ] Set `CORS_ORIGINS` to your actual frontend URL only
- [ ] Remove the `pgadmin` service from docker-compose or secure it
- [ ] Set up SSL/TLS (nginx reverse proxy recommended)
- [ ] Configure `LOG_FORMAT=json` for log aggregation
- [ ] Set up database backups
- [ ] Monitor with Grafana + Prometheus (optional)
