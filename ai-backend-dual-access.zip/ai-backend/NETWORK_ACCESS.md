# 🌐 Network Access Guide — AI Backend API

This guide covers three scenarios for making your API accessible beyond localhost.

---

## Architecture Overview

```
Internet / LAN
      │
      ▼
  ┌────────┐   port 80/443    ┌─────────┐
  │ Nginx  │ ──────────────▶  │   API   │  (FastAPI, port 8000 internal)
  │ Proxy  │                  └─────────┘
  └────────┘                       │
      │                       ┌────┴────┐
   SSL/TLS                    │   DB    │  (PostgreSQL - internal only)
   Rate Limit                 └─────────┘
   Security Headers
```

Nginx is the **only service** exposed to the outside world.
PostgreSQL and Redis stay internal, protected inside Docker's network.

---

## Scenario 1 — Local Network (LAN / WiFi) with HTTPS

Best for: demos, internal tools, home lab, office use.

### Step 1 — Find Your Machine's LAN IP

```bash
hostname -I | awk '{print $1}'
# Example output: 192.168.1.105
```

### Step 2 — Generate a Self-Signed SSL Certificate

```bash
chmod +x generate-ssl.sh
./generate-ssl.sh
# Creates nginx/ssl/cert.pem and nginx/ssl/key.pem
```

### Step 3 — Update CORS in .env

```env
# backend/.env
CORS_ORIGINS=https://192.168.1.105,http://localhost:3000,https://localhost:3000
```

### Step 4 — Start Everything

```bash
docker compose up -d --build
docker compose run --rm migrate
```

### Step 5 — Access from Any Device on the Same Network

```
https://192.168.1.105/docs          ← Swagger UI
https://192.168.1.105/api/v1/health ← Health check
```

> ⚠️ **Browser warning about self-signed cert**: Click **Advanced** → **Proceed to <IP>**
> This is normal for self-signed certificates. Your data is still encrypted.

### Step 6 — Open Ubuntu Firewall (if enabled)

```bash
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw status
```

---

## Scenario 2 — Public Internet with a Real Domain (HTTPS + Let's Encrypt)

Best for: deployed applications, APIs accessed by external clients/frontends.

### Prerequisites

- A VPS / cloud server (DigitalOcean, AWS, Hetzner, etc.)
- A domain name pointing to your server's public IP
- Port 80 and 443 open on your server's firewall/security group

### Step 1 — Point Your Domain to Your Server

In your DNS provider (e.g. Cloudflare, Namecheap):
```
Type: A
Name: api          (or @ for root domain)
Value: <your server's public IP>
TTL:  300
```

Wait for DNS to propagate (1–10 minutes). Test with:
```bash
nslookup api.yourdomain.com
# Should return your server's IP
```

### Step 2 — Get a Free Let's Encrypt Certificate

```bash
chmod +x certbot-setup.sh
./certbot-setup.sh api.yourdomain.com
```

This will:
- Install certbot
- Obtain a certificate from Let's Encrypt
- Update nginx.conf to use the certificate
- Set up auto-renewal via cron

### Step 3 — Update .env

```env
CORS_ORIGINS=https://api.yourdomain.com,https://yourfrontend.com
```

### Step 4 — Start / Restart

```bash
docker compose up -d --build
docker compose run --rm migrate
```

### Step 5 — Access Your API

```
https://api.yourdomain.com/docs
https://api.yourdomain.com/api/v1/health
```

### Open Cloud Firewall

**AWS EC2 Security Group** (via AWS Console):
- Inbound: TCP 80, TCP 443, Source: 0.0.0.0/0

**DigitalOcean Firewall** (via control panel):
- Inbound Rules: HTTP (80), HTTPS (443), All sources

**Ubuntu UFW**:
```bash
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable
```

---

## Scenario 3 — Development Mode (LAN access, no HTTPS)

Best for: quick demos, testing from your phone on the same WiFi.
No SSL, direct port 8000 access.

```bash
# Start in dev mode (exposes port 8000 on all interfaces)
docker compose --profile dev up -d postgres redis
docker compose --profile dev up -d api-dev
docker compose run --rm migrate
```

Access from any device on the same network:
```
http://192.168.1.105:8000/docs
http://192.168.1.105:8000/api/v1/health
```

Update CORS:
```env
CORS_ORIGINS=http://192.168.1.105:3000,http://localhost:3000
```

---

## Quick Reference — Access URLs

| Scenario | URL | Notes |
|----------|-----|-------|
| Local (this machine) | `http://localhost:8000/docs` | No nginx |
| LAN / self-signed | `https://192.168.1.x/docs` | Browser warning OK |
| Public domain | `https://api.yourdomain.com/docs` | Trusted cert |
| Dev mode (LAN) | `http://192.168.1.x:8000/docs` | No SSL |

---

## Connecting a Frontend

### React / Next.js

```javascript
// .env.local or .env
NEXT_PUBLIC_API_URL=https://192.168.1.105    # LAN
NEXT_PUBLIC_API_URL=https://api.yourdomain.com  # Production

// api.js
const API = process.env.NEXT_PUBLIC_API_URL + "/api/v1";
```

### Vue / Vite

```javascript
// .env
VITE_API_URL=https://192.168.1.105/api/v1
```

### Flutter / Mobile

```dart
const String apiBase = "https://192.168.1.105/api/v1";
// Note: for self-signed certs in Flutter, you need to trust the cert
```

---

## Firewall Summary

```bash
# Open ports for public/LAN access
sudo ufw allow 80/tcp comment "HTTP"
sudo ufw allow 443/tcp comment "HTTPS"

# Optional: keep SSH open if using a remote server
sudo ufw allow 22/tcp comment "SSH"

# Enable firewall
sudo ufw enable

# Check status
sudo ufw status verbose
```

---

## Security Tips

- **Never expose PostgreSQL (5432) or Redis (6379) to the internet** — they are bound to `127.0.0.1` only in docker-compose.yml.
- **Change default passwords** in `.env` before going live.
- **Rotate your SECRET_KEY** — run `openssl rand -hex 32` and put it in `.env`.
- **Limit CORS_ORIGINS** to only your actual frontend domains.
- The nginx config already includes rate limiting:
  - Auth endpoints: 10 requests/min
  - All others: 100 requests/min
