"""
tests/conftest.py
──────────────────
Pytest configuration and shared fixtures.
Uses a separate test database so tests never touch production data.
"""

import asyncio
from typing import AsyncGenerator

import pytest
import pytest_asyncio
from fastapi import FastAPI
from httpx import AsyncClient, ASGITransport
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.pool import NullPool

# ── Test database URL ─────────────────────────────────────────────────────────
# Uses SQLite in-memory for speed. Switch to PostgreSQL for full compatibility.
TEST_DATABASE_URL = "sqlite+aiosqlite:///:memory:"

# If you want to use PostgreSQL for tests:
# TEST_DATABASE_URL = "postgresql+asyncpg://ai_user:password@localhost:5432/ai_backend_test"


@pytest.fixture(scope="session")
def event_loop():
    """Create a single event loop for the entire test session."""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


@pytest_asyncio.fixture(scope="session")
async def test_engine():
    """Create the test database engine."""
    engine = create_async_engine(
        TEST_DATABASE_URL,
        poolclass=NullPool,
        echo=False,
    )

    # Create all tables
    from app.db.base import Base
    import app.models  # noqa – registers all models
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    yield engine

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
    await engine.dispose()


@pytest_asyncio.fixture
async def db_session(test_engine) -> AsyncGenerator[AsyncSession, None]:
    """Provide a clean database session for each test (rolled back after)."""
    session_factory = async_sessionmaker(
        bind=test_engine,
        class_=AsyncSession,
        expire_on_commit=False,
    )

    async with session_factory() as session:
        yield session
        await session.rollback()  # rollback all changes after each test


@pytest_asyncio.fixture
async def client(db_session: AsyncSession) -> AsyncGenerator[AsyncClient, None]:
    """
    Provide an async HTTP test client with the DB overridden.
    All requests go through the real FastAPI app, but use the test DB.
    """
    from app.core.dependencies import get_db
    from app.main import app

    # Override the DB dependency to use our test session
    async def override_get_db():
        yield db_session

    app.dependency_overrides[get_db] = override_get_db

    async with AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://test",
    ) as ac:
        yield ac

    app.dependency_overrides.clear()


# ── Test data factories ───────────────────────────────────────────────────────

@pytest_asyncio.fixture
async def test_user(db_session: AsyncSession):
    """Create a standard test user."""
    from app.core.security import hash_password
    from app.models.user import User

    user = User(
        username="testuser",
        email="test@example.com",
        hashed_password=hash_password("TestPassword1"),
        role="user",
        is_active=True,
    )
    db_session.add(user)
    await db_session.flush()
    return user


@pytest_asyncio.fixture
async def test_admin(db_session: AsyncSession):
    """Create a test admin user."""
    from app.core.security import hash_password
    from app.models.user import User

    admin = User(
        username="testadmin",
        email="admin@example.com",
        hashed_password=hash_password("AdminPassword1"),
        role="admin",
        is_active=True,
    )
    db_session.add(admin)
    await db_session.flush()
    return admin


@pytest_asyncio.fixture
async def user_token(test_user) -> str:
    """Return a valid JWT access token for the test user."""
    from app.core.security import create_access_token
    return create_access_token(str(test_user.id), role="user")


@pytest_asyncio.fixture
async def admin_token(test_admin) -> str:
    """Return a valid JWT access token for the test admin."""
    from app.core.security import create_access_token
    return create_access_token(str(test_admin.id), role="admin")
