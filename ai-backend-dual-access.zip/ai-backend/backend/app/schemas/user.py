"""
app/schemas/user.py
────────────────────
Pydantic models for User request/response validation.
These are completely separate from SQLAlchemy models.
"""

import uuid
from datetime import datetime
from typing import Literal

from pydantic import BaseModel, EmailStr, Field, field_validator


# ── Request schemas (incoming data) ──────────────────────────────────────────

class UserRegister(BaseModel):
    """Payload for POST /auth/register"""

    username: str = Field(
        ...,
        min_length=3,
        max_length=50,
        pattern=r"^[a-zA-Z0-9_-]+$",
        examples=["john_doe"],
    )
    email: EmailStr
    password: str = Field(..., min_length=8, max_length=128)

    @field_validator("password")
    @classmethod
    def password_strength(cls, v: str) -> str:
        """Ensure password has at least one digit and one uppercase letter."""
        if not any(c.isupper() for c in v):
            raise ValueError("Password must contain at least one uppercase letter")
        if not any(c.isdigit() for c in v):
            raise ValueError("Password must contain at least one digit")
        return v


class UserLogin(BaseModel):
    """Payload for POST /auth/login"""

    email: EmailStr
    password: str


class UserUpdate(BaseModel):
    """Payload for PATCH /users/me – all fields optional"""

    username: str | None = Field(None, min_length=3, max_length=50)
    email: EmailStr | None = None


class PasswordChange(BaseModel):
    """Payload for POST /users/me/change-password"""

    current_password: str
    new_password: str = Field(..., min_length=8)

    @field_validator("new_password")
    @classmethod
    def password_strength(cls, v: str) -> str:
        if not any(c.isupper() for c in v):
            raise ValueError("New password must contain at least one uppercase letter")
        if not any(c.isdigit() for c in v):
            raise ValueError("New password must contain at least one digit")
        return v


# ── Response schemas (outgoing data) ─────────────────────────────────────────

class UserResponse(BaseModel):
    """Safe user representation – never includes the password."""

    id: uuid.UUID
    username: str
    email: EmailStr
    role: str
    is_active: bool
    is_verified: bool
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}   # read from ORM objects


class UserListResponse(BaseModel):
    """Used by admin endpoint GET /admin/users"""

    users: list[UserResponse]
    total: int
    page: int
    page_size: int


# ── Token schemas ─────────────────────────────────────────────────────────────

class TokenResponse(BaseModel):
    """Returned on login and token refresh."""

    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int  # seconds until access token expires


class RefreshTokenRequest(BaseModel):
    """Payload for POST /auth/refresh"""

    refresh_token: str


class TokenPayload(BaseModel):
    """Internal representation of decoded JWT claims."""

    sub: str
    type: str
    role: str = "user"
    exp: int
    iat: int
