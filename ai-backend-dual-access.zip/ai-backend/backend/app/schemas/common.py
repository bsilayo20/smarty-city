"""
app/schemas/common.py
──────────────────────
Shared schemas used across multiple endpoints.
"""

from typing import Any, Generic, TypeVar

from pydantic import BaseModel

T = TypeVar("T")


class SuccessResponse(BaseModel, Generic[T]):
    """Standard success envelope wrapping any data payload."""

    success: bool = True
    data: T
    message: str | None = None


class MessageResponse(BaseModel):
    """Simple success message with no data payload."""

    success: bool = True
    message: str


class HealthCheckResponse(BaseModel):
    """Returned by GET /health"""

    status: str                      # "healthy" | "degraded" | "unhealthy"
    version: str
    environment: str
    services: dict[str, str]         # service_name → "ok" | "error"


class PaginationParams(BaseModel):
    """Reusable pagination query parameters."""

    page: int = 1
    page_size: int = 20


class AdminStatsResponse(BaseModel):
    """Summary stats for the admin dashboard."""

    total_users: int
    active_users: int
    total_messages: int
    total_tokens_used: int
    estimated_cost_usd: float
    messages_today: int
    top_users: list[dict[str, Any]]
