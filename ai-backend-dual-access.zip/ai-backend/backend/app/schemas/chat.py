"""
app/schemas/chat.py
────────────────────
Pydantic models for AI Chat request/response validation.
"""

import uuid
from datetime import datetime

from pydantic import BaseModel, Field


# ── Request schemas ───────────────────────────────────────────────────────────

class ChatRequest(BaseModel):
    """Payload for POST /chat"""

    prompt: str = Field(
        ...,
        min_length=1,
        max_length=10000,
        examples=["Explain how async/await works in Python."],
    )
    # Optional: override the system-level AI provider per-request
    provider: str | None = Field(
        None,
        description="Override AI provider: 'openai' or 'gemini'",
        examples=["openai"],
    )
    stream: bool = Field(
        False,
        description="If True, response is streamed as Server-Sent Events",
    )


class ChatHistoryParams(BaseModel):
    """Query params for GET /chat/history"""

    page: int = Field(1, ge=1)
    page_size: int = Field(20, ge=1, le=100)


# ── Response schemas ──────────────────────────────────────────────────────────

class ChatMessageResponse(BaseModel):
    """Represents a single stored chat exchange."""

    id: uuid.UUID
    user_id: uuid.UUID
    prompt: str
    response: str | None
    model_used: str | None
    provider: str | None
    prompt_tokens: int | None
    completion_tokens: int | None
    total_tokens: int | None
    latency_seconds: float | None
    from_cache: bool
    status: str
    error_message: str | None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class ChatResponse(BaseModel):
    """Returned by POST /chat (non-streaming)."""

    message: ChatMessageResponse
    # Convenience top-level fields for easy frontend access
    response_text: str | None
    from_cache: bool


class ChatHistoryResponse(BaseModel):
    """Returned by GET /chat/history"""

    messages: list[ChatMessageResponse]
    total: int
    page: int
    page_size: int
    has_next: bool


# ── Admin chat schemas ────────────────────────────────────────────────────────

class AdminChatListResponse(BaseModel):
    """All chats across all users – admin only."""

    messages: list[ChatMessageResponse]
    total: int
    page: int
    page_size: int
