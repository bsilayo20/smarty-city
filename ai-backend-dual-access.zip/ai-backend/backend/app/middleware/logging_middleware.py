"""
app/middleware/logging_middleware.py
─────────────────────────────────────
ASGI middleware that logs every HTTP request with:
  • method, path, status code
  • latency in milliseconds
  • user agent
"""

import time
import uuid

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

from app.core.logging import get_logger

logger = get_logger(__name__)


class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """
    Logs incoming requests and outgoing responses.
    Adds an X-Request-ID header to every response for tracing.
    """

    async def dispatch(self, request: Request, call_next) -> Response:
        # Generate a unique request ID
        request_id = str(uuid.uuid4())[:8]
        start_time = time.monotonic()

        # Skip logging for health checks (too noisy in production)
        skip_paths = {"/health", "/ping", "/api/v1/health", "/api/v1/ping"}

        try:
            response = await call_next(request)
        except Exception as exc:
            duration_ms = round((time.monotonic() - start_time) * 1000, 2)
            logger.error(
                "Request failed with exception",
                request_id=request_id,
                method=request.method,
                path=request.url.path,
                duration_ms=duration_ms,
                exc_info=exc,
            )
            raise

        duration_ms = round((time.monotonic() - start_time) * 1000, 2)

        if request.url.path not in skip_paths:
            log_fn = logger.warning if response.status_code >= 400 else logger.info
            log_fn(
                "HTTP request",
                request_id=request_id,
                method=request.method,
                path=request.url.path,
                status_code=response.status_code,
                duration_ms=duration_ms,
                client_ip=request.client.host if request.client else "unknown",
                user_agent=request.headers.get("user-agent", ""),
            )

        # Attach request ID to response header for client-side tracing
        response.headers["X-Request-ID"] = request_id
        return response
