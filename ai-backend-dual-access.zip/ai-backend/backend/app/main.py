"""
app/main.py
────────────
FastAPI application factory.
This is the entry point started by Uvicorn.

Startup sequence:
  1. Configure logging
  2. Create FastAPI app with metadata
  3. Register middlewares (CORS, logging)
  4. Register exception handlers
  5. Include API routes
  6. On startup: check DB, seed initial data
"""

from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.v1.router import api_router
from app.core.config import settings
from app.core.exceptions import register_exception_handlers
from app.core.logging import get_logger, setup_logging
from app.middleware.logging_middleware import RequestLoggingMiddleware

# Configure logging first so every subsequent log is formatted correctly
setup_logging()
logger = get_logger(__name__)


# ── Lifespan (startup / shutdown) ────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Code here runs BEFORE the server starts accepting requests.
    Use it for DB checks, cache warming, seeding initial data.
    """
    logger.info(
        "Starting up",
        app=settings.APP_NAME,
        version=settings.APP_VERSION,
        environment=settings.ENVIRONMENT,
    )

    # ── Check database connection ────────────────────────────
    from app.db.session import check_db_connection
    db_ok = await check_db_connection()
    if not db_ok:
        logger.error("Cannot connect to PostgreSQL – check DATABASE_URL in .env")
    else:
        logger.info("PostgreSQL connection OK")

        # ── Seed initial data ──────────────────────────────────
        from app.db.init_db import init_db
        from app.db.session import AsyncSessionLocal
        async with AsyncSessionLocal() as session:
            await init_db(session)
            await session.commit()

    # ── Check Redis connection ───────────────────────────────
    try:
        import redis.asyncio as aioredis
        r = aioredis.from_url(settings.REDIS_URL, socket_connect_timeout=2)
        await r.ping()
        await r.aclose()
        logger.info("Redis connection OK")
    except Exception as exc:
        logger.warning("Redis unavailable – caching disabled", error=str(exc))

    logger.info("Application startup complete. Ready to serve requests.")

    yield  # ← application runs here

    # ── Shutdown ─────────────────────────────────────────────
    logger.info("Shutting down application")
    from app.db.session import engine
    await engine.dispose()
    logger.info("Database connections closed")


# ── Application factory ───────────────────────────────────────────────────────

def create_app() -> FastAPI:
    """Create and configure the FastAPI application instance."""

    app = FastAPI(
        title=settings.APP_NAME,
        version=settings.APP_VERSION,
        description=(
            "## AI Backend API\n\n"
            "A production-ready FastAPI backend with:\n"
            "- 🔐 JWT Authentication (access + refresh tokens)\n"
            "- 🤖 AI Chat (OpenAI / Gemini) with Redis caching\n"
            "- 🛡️ Role-based access control (user / admin)\n"
            "- 📊 Usage tracking and admin dashboard\n\n"
            "### Authentication\n"
            "Use `POST /api/v1/auth/login` to get a token, then click "
            "**Authorize** above and enter `Bearer <your_token>`."
        ),
        openapi_url="/api/v1/openapi.json",
        docs_url="/docs",           # Swagger UI
        redoc_url="/redoc",         # ReDoc alternative UI
        contact={
            "name": "Backend Team",
            "email": "dev@example.com",
        },
        license_info={
            "name": "MIT",
        },
        lifespan=lifespan,
    )

    # ── CORS ─────────────────────────────────────────────────
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.CORS_ORIGINS_LIST,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
        expose_headers=["X-Request-ID"],
    )

    # ── Request logging ───────────────────────────────────────
    app.add_middleware(RequestLoggingMiddleware)

    # ── Exception handlers ────────────────────────────────────
    register_exception_handlers(app)

    # ── Routes ───────────────────────────────────────────────
    app.include_router(api_router)

    # Root redirect to docs
    @app.get("/", include_in_schema=False)
    async def root():
        from fastapi.responses import RedirectResponse
        return RedirectResponse(url="/docs")

    return app


# ── Create the app instance ───────────────────────────────────────────────────
app = create_app()
