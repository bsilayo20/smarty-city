"""
app/api/v1/router.py
─────────────────────
Collects all v1 endpoint routers into a single APIRouter.
Imported once in main.py.
"""

from fastapi import APIRouter

from app.api.v1.endpoints import admin, auth, chat, health, users

# Prefix all v1 routes with /api/v1
api_router = APIRouter(prefix="/api/v1")

# ── Mount each sub-router ─────────────────────────────────────────────────────
api_router.include_router(health.router)          # GET  /api/v1/health
api_router.include_router(auth.router)            # POST /api/v1/auth/...
api_router.include_router(users.router)           # GET  /api/v1/users/...
api_router.include_router(chat.router)            # POST /api/v1/chat/...
api_router.include_router(admin.router)           # GET  /api/v1/admin/...
