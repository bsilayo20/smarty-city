"""
app/api/v1/endpoints/chat.py
─────────────────────────────
AI Chat routes:
  POST /chat               – send a message, get AI response
  POST /chat/stream        – streaming SSE version
  GET  /chat/history       – current user's chat history
  DELETE /chat/{id}        – delete a specific message
"""

import asyncio

from fastapi import APIRouter, Depends, Query, status
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_current_user, get_db, get_redis
from app.schemas.chat import (
    ChatHistoryResponse,
    ChatMessageResponse,
    ChatRequest,
    ChatResponse,
)
from app.schemas.common import MessageResponse, SuccessResponse
from app.services import chat_service

router = APIRouter(prefix="/chat", tags=["AI Chat"])


@router.post(
    "",
    response_model=ChatResponse,
    status_code=status.HTTP_200_OK,
    summary="Send a message to the AI",
    description=(
        "Submit a prompt to the configured AI provider (OpenAI or Gemini). "
        "Responses are cached in Redis to avoid duplicate API calls. "
        "Set `stream: true` to use Server-Sent Events streaming instead."
    ),
)
async def chat(
    payload: ChatRequest,
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    redis=Depends(get_redis),
):
    """
    Non-streaming chat endpoint.
    Saves the full exchange to the database and returns the complete response.
    """
    if payload.stream:
        # Redirect to the streaming endpoint logic
        return await _handle_chat(payload, current_user, db, redis)

    message = await chat_service.create_chat_message(
        user=current_user,
        prompt=payload.prompt,
        db=db,
        redis_client=redis,
        provider=payload.provider,
    )

    return ChatResponse(
        message=ChatMessageResponse.model_validate(message),
        response_text=message.response,
        from_cache=message.from_cache,
    )


@router.post(
    "/stream",
    summary="Stream AI response via Server-Sent Events",
    description=(
        "Stream the AI response token-by-token using Server-Sent Events (SSE). "
        "The client receives `data: <chunk>` lines as they arrive. "
        "The final event is `data: [DONE]`."
    ),
)
async def chat_stream(
    payload: ChatRequest,
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    redis=Depends(get_redis),
):
    """
    Streaming chat endpoint.
    Returns a StreamingResponse with SSE format:
      data: Hello
      data:  world
      data: [DONE]
    """
    from app.services.ai_service import stream_ai_response

    async def event_generator():
        full_response = []
        try:
            async for chunk in stream_ai_response(
                prompt=payload.prompt,
                provider=payload.provider,
            ):
                full_response.append(chunk)
                # SSE format requires "data: " prefix and double newline
                yield f"data: {chunk}\n\n"

            yield "data: [DONE]\n\n"

            # Save the complete response to DB after streaming
            complete_text = "".join(full_response)
            from app.models.chat import ChatMessage
            message = ChatMessage(
                user_id=current_user.id,
                prompt=payload.prompt,
                response=complete_text,
                provider=payload.provider or "openai",
                status="completed",
                from_cache=False,
            )
            db.add(message)
            await db.commit()

        except Exception as exc:
            yield f"data: [ERROR] {str(exc)}\n\n"

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",   # disable nginx buffering
        },
    )


@router.get(
    "/history",
    response_model=ChatHistoryResponse,
    summary="Get current user's chat history",
)
async def get_history(
    page: int = Query(1, ge=1, description="Page number"),
    page_size: int = Query(20, ge=1, le=100, description="Items per page"),
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Return paginated chat history for the authenticated user, newest first."""
    messages, total = await chat_service.get_user_chat_history(
        user_id=current_user.id,
        db=db,
        page=page,
        page_size=page_size,
    )

    return ChatHistoryResponse(
        messages=[ChatMessageResponse.model_validate(m) for m in messages],
        total=total,
        page=page,
        page_size=page_size,
        has_next=(page * page_size) < total,
    )


@router.delete(
    "/{message_id}",
    response_model=MessageResponse,
    summary="Delete a chat message",
)
async def delete_message(
    message_id: str,
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete a specific chat message. Users can only delete their own messages."""
    import uuid
    await chat_service.delete_chat_message(
        message_id=uuid.UUID(message_id),
        user_id=current_user.id,
        db=db,
        is_admin=False,
    )
    return MessageResponse(message="Message deleted successfully")


# ── Internal helper ───────────────────────────────────────────────────────────

async def _handle_chat(payload, current_user, db, redis):
    """Shared logic extracted to avoid code duplication."""
    message = await chat_service.create_chat_message(
        user=current_user,
        prompt=payload.prompt,
        db=db,
        redis_client=redis,
        provider=payload.provider,
    )
    return ChatResponse(
        message=ChatMessageResponse.model_validate(message),
        response_text=message.response,
        from_cache=message.from_cache,
    )
