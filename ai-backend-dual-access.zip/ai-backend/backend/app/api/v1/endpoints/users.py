"""
app/api/v1/endpoints/users.py
──────────────────────────────
User self-service routes:
  GET    /users/me                – get own profile
  PATCH  /users/me                – update profile
  POST   /users/me/change-password – change password
"""

from fastapi import APIRouter, Depends, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_current_user, get_db
from app.schemas.common import MessageResponse, SuccessResponse
from app.schemas.user import PasswordChange, UserResponse, UserUpdate
from app.services import user_service

router = APIRouter(prefix="/users", tags=["Users"])


@router.get(
    "/me",
    response_model=SuccessResponse[UserResponse],
    summary="Get your user profile",
)
async def get_profile(current_user=Depends(get_current_user)):
    """Returns the full profile of the currently authenticated user."""
    return SuccessResponse(data=UserResponse.model_validate(current_user))


@router.patch(
    "/me",
    response_model=SuccessResponse[UserResponse],
    summary="Update your user profile",
)
async def update_profile(
    payload: UserUpdate,
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update your username and/or email. All fields are optional."""
    updated = await user_service.update_user(current_user, payload, db)
    return SuccessResponse(
        data=UserResponse.model_validate(updated),
        message="Profile updated successfully",
    )


@router.post(
    "/me/change-password",
    response_model=MessageResponse,
    status_code=status.HTTP_200_OK,
    summary="Change your password",
)
async def change_password(
    payload: PasswordChange,
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Change your password.
    Requires your current password for verification.
    """
    await user_service.change_password(current_user, payload, db)
    return MessageResponse(message="Password changed successfully")
