"""
app/api/v1/endpoints/auth.py
─────────────────────────────
Authentication routes:
  POST /auth/register   – create account
  POST /auth/login      – get token pair
  POST /auth/refresh    – exchange refresh token
  GET  /auth/me         – current user info
"""

from fastapi import APIRouter, Depends, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_current_user, get_db
from app.schemas.common import SuccessResponse
from app.schemas.user import (
    RefreshTokenRequest,
    TokenResponse,
    UserLogin,
    UserRegister,
    UserResponse,
)
from app.services import auth_service

router = APIRouter(prefix="/auth", tags=["Authentication"])


@router.post(
    "/register",
    response_model=SuccessResponse[UserResponse],
    status_code=status.HTTP_201_CREATED,
    summary="Register a new user account",
    description=(
        "Create a new user account. Username must be 3–50 alphanumeric chars. "
        "Password must be at least 8 chars with one uppercase letter and one digit."
    ),
)
async def register(
    payload: UserRegister,
    db: AsyncSession = Depends(get_db),
):
    user = await auth_service.register_user(payload, db)
    return SuccessResponse(
        data=UserResponse.model_validate(user),
        message="Account created successfully. Welcome!",
    )


@router.post(
    "/login",
    response_model=TokenResponse,
    summary="Login – returns JWT access + refresh tokens",
    description=(
        "Authenticate with email and password. "
        "Returns a short-lived access_token and a long-lived refresh_token."
    ),
)
async def login(
    payload: UserLogin,
    db: AsyncSession = Depends(get_db),
):
    return await auth_service.login_user(payload.email, payload.password, db)


@router.post(
    "/refresh",
    response_model=TokenResponse,
    summary="Refresh access token",
    description="Exchange a valid refresh_token for a new access + refresh token pair.",
)
async def refresh(
    payload: RefreshTokenRequest,
    db: AsyncSession = Depends(get_db),
):
    return await auth_service.refresh_tokens(payload.refresh_token, db)


@router.get(
    "/me",
    response_model=SuccessResponse[UserResponse],
    summary="Get currently authenticated user",
)
async def get_me(current_user=Depends(get_current_user)):
    """Returns the user profile associated with the provided access token."""
    return SuccessResponse(data=UserResponse.model_validate(current_user))
