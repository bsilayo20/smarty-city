"""
app/api/v1/endpoints/health.py
───────────────────────────────
Health check endpoint – used by Docker, k8s liveness/readiness probes,
load balancers, and monitoring tools.
"""

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.dependencies import get_db, get_redis
from app.db.session import check_db_connection
from app.schemas.common import HealthCheckResponse

router = APIRouter(tags=["System"])


@router.get(
    "/health",
    response_model=HealthCheckResponse,
    summary="System health check",
    description=(
        "Returns the health status of the application and its dependencies. "
        "Returns HTTP 200 if all services are up, HTTP 503 if any are degraded."
    ),
)
async def health_check(
    db: AsyncSession = Depends(get_db),
    redis=Depends(get_redis),
):
    services: dict[str, str] = {}

    # ── Check PostgreSQL ─────────────────────────────────────
    db_ok = await check_db_connection()
    services["postgresql"] = "ok" if db_ok else "error"

    # ── Check Redis ───────────────────────────────────────────
    if redis:
        try:
            await redis.ping()
            services["redis"] = "ok"
        except Exception:
            services["redis"] = "error"
    else:
        services["redis"] = "unavailable"

    # ── Overall status ────────────────────────────────────────
    all_ok = all(v == "ok" for v in services.values())
    any_error = any(v == "error" for v in services.values())

    if all_ok:
        overall = "healthy"
    elif any_error:
        overall = "degraded"
    else:
        overall = "degraded"

    return HealthCheckResponse(
        status=overall,
        version=settings.APP_VERSION,
        environment=settings.ENVIRONMENT,
        services=services,
    )


@router.get(
    "/ping",
    include_in_schema=False,   # hidden from Swagger – used by load balancers
)
async def ping():
    """Minimal liveness check – returns instantly without DB calls."""
    return {"status": "ok"}
