"""
app/api/v1/endpoints/admin.py
──────────────────────────────
Admin-only routes (require role == "admin"):
  GET    /admin/users              – list all users
  DELETE /admin/users/{id}         – delete a user
  PATCH  /admin/users/{id}/toggle  – activate/deactivate
  GET    /admin/chats              – all chat messages
  GET    /admin/stats              – usage statistics
"""

from fastapi import APIRouter, Depends, Query, status
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_current_admin, get_db
from app.schemas.chat import AdminChatListResponse, ChatMessageResponse
from app.schemas.common import AdminStatsResponse, MessageResponse, SuccessResponse
from app.schemas.user import UserListResponse, UserResponse
from app.services import chat_service, user_service

router = APIRouter(prefix="/admin", tags=["Admin"])


# ── Users ─────────────────────────────────────────────────────────────────────

@router.get(
    "/users",
    response_model=UserListResponse,
    summary="[Admin] List all users",
)
async def list_all_users(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    role: str | None = Query(None, description="Filter by role: 'user' or 'admin'"),
    admin=Depends(get_current_admin),
    db: AsyncSession = Depends(get_db),
):
    """Returns paginated list of all registered users."""
    users, total = await user_service.list_users(db, page, page_size, role)
    return UserListResponse(
        users=[UserResponse.model_validate(u) for u in users],
        total=total,
        page=page,
        page_size=page_size,
    )


@router.delete(
    "/users/{user_id}",
    response_model=MessageResponse,
    summary="[Admin] Delete a user",
)
async def delete_user(
    user_id: str,
    admin=Depends(get_current_admin),
    db: AsyncSession = Depends(get_db),
):
    """Permanently delete a user and all their data (cascade)."""
    import uuid
    await user_service.admin_delete_user(uuid.UUID(user_id), admin, db)
    return MessageResponse(message=f"User {user_id} deleted successfully")


@router.patch(
    "/users/{user_id}/toggle",
    response_model=SuccessResponse[UserResponse],
    summary="[Admin] Activate or deactivate a user",
)
async def toggle_user(
    user_id: str,
    is_active: bool = Query(..., description="Set to true to activate, false to deactivate"),
    admin=Depends(get_current_admin),
    db: AsyncSession = Depends(get_db),
):
    import uuid
    user = await user_service.toggle_user_active(uuid.UUID(user_id), is_active, db)
    action = "activated" if is_active else "deactivated"
    return SuccessResponse(
        data=UserResponse.model_validate(user),
        message=f"User {action} successfully",
    )


# ── Chats ─────────────────────────────────────────────────────────────────────

@router.get(
    "/chats",
    response_model=AdminChatListResponse,
    summary="[Admin] List all chat messages",
)
async def list_all_chats(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    admin=Depends(get_current_admin),
    db: AsyncSession = Depends(get_db),
):
    """Returns all AI chat messages across all users, paginated."""
    messages, total = await chat_service.get_all_chats(db, page, page_size)
    return AdminChatListResponse(
        messages=[ChatMessageResponse.model_validate(m) for m in messages],
        total=total,
        page=page,
        page_size=page_size,
    )


@router.delete(
    "/chats/{message_id}",
    response_model=MessageResponse,
    summary="[Admin] Delete any chat message",
)
async def admin_delete_message(
    message_id: str,
    admin=Depends(get_current_admin),
    db: AsyncSession = Depends(get_db),
):
    import uuid
    await chat_service.delete_chat_message(
        message_id=uuid.UUID(message_id),
        user_id=admin.id,
        db=db,
        is_admin=True,
    )
    return MessageResponse(message="Message deleted")


# ── Stats ─────────────────────────────────────────────────────────────────────

@router.get(
    "/stats",
    response_model=AdminStatsResponse,
    summary="[Admin] View AI usage statistics",
)
async def get_stats(
    admin=Depends(get_current_admin),
    db: AsyncSession = Depends(get_db),
):
    """Returns aggregate usage statistics across all users."""
    from app.models.api_usage import APIUsage
    from app.models.chat import ChatMessage
    from app.models.user import User
    from datetime import date

    # Total users
    total_users = (await db.execute(select(func.count(User.id)))).scalar_one()
    active_users = (
        await db.execute(select(func.count(User.id)).where(User.is_active == True))
    ).scalar_one()

    # Total messages
    total_messages = (
        await db.execute(select(func.count(ChatMessage.id)))
    ).scalar_one()

    # Messages today
    today = date.today()
    messages_today = (
        await db.execute(
            select(func.count(ChatMessage.id)).where(
                func.date(ChatMessage.created_at) == today
            )
        )
    ).scalar_one()

    # Token totals
    token_result = await db.execute(
        select(
            func.coalesce(func.sum(APIUsage.total_tokens), 0),
            func.coalesce(func.sum(APIUsage.estimated_cost_usd), 0.0),
        )
    )
    total_tokens, total_cost = token_result.one()

    # Top 5 users by message count
    top_users_result = await db.execute(
        select(User.username, User.email, func.count(ChatMessage.id).label("msg_count"))
        .join(ChatMessage, ChatMessage.user_id == User.id, isouter=True)
        .group_by(User.id, User.username, User.email)
        .order_by(func.count(ChatMessage.id).desc())
        .limit(5)
    )
    top_users = [
        {"username": row.username, "email": row.email, "message_count": row.msg_count}
        for row in top_users_result
    ]

    return AdminStatsResponse(
        total_users=total_users,
        active_users=active_users,
        total_messages=total_messages,
        total_tokens_used=int(total_tokens),
        estimated_cost_usd=float(total_cost),
        messages_today=messages_today,
        top_users=top_users,
    )
