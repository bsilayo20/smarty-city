"""
app/services/ai_service.py
───────────────────────────
Abstraction layer over AI providers (OpenAI, Gemini).
Handles:
  • Provider selection
  • Redis response caching
  • Retry logic with exponential back-off
  • Streaming responses
  • Token tracking
"""

import hashlib
import json
import time
from typing import AsyncGenerator

import redis.asyncio as aioredis
from tenacity import retry, stop_after_attempt, wait_exponential

from app.core.config import settings
from app.core.exceptions import AIServiceException
from app.core.logging import get_logger

logger = get_logger(__name__)

# ── Cache key helper ─────────────────────────────────────────────────────────

def _cache_key(provider: str, model: str, prompt: str) -> str:
    """Deterministic cache key based on provider + model + prompt hash."""
    digest = hashlib.sha256(prompt.encode()).hexdigest()[:16]
    return f"ai_cache:{provider}:{model}:{digest}"


# ── AI response dataclass ─────────────────────────────────────────────────────

class AIResponse:
    """Structured result from any AI provider."""

    def __init__(
        self,
        text: str,
        model: str,
        provider: str,
        prompt_tokens: int = 0,
        completion_tokens: int = 0,
        total_tokens: int = 0,
        from_cache: bool = False,
        latency_seconds: float = 0.0,
    ):
        self.text = text
        self.model = model
        self.provider = provider
        self.prompt_tokens = prompt_tokens
        self.completion_tokens = completion_tokens
        self.total_tokens = total_tokens
        self.from_cache = from_cache
        self.latency_seconds = latency_seconds


# ── OpenAI provider ───────────────────────────────────────────────────────────

@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=2, max=10),
    reraise=True,
)
async def _call_openai(prompt: str) -> AIResponse:
    """Call OpenAI Chat Completions API with retry logic."""
    from openai import AsyncOpenAI, OpenAIError

    client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY)

    start = time.monotonic()
    try:
        completion = await client.chat.completions.create(
            model=settings.OPENAI_MODEL,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=settings.AI_MAX_TOKENS,
            temperature=settings.AI_TEMPERATURE,
        )
    except OpenAIError as exc:
        logger.error("OpenAI API error", error=str(exc))
        raise AIServiceException(f"OpenAI error: {exc}") from exc

    latency = time.monotonic() - start
    choice = completion.choices[0]
    usage = completion.usage

    return AIResponse(
        text=choice.message.content or "",
        model=completion.model,
        provider="openai",
        prompt_tokens=usage.prompt_tokens if usage else 0,
        completion_tokens=usage.completion_tokens if usage else 0,
        total_tokens=usage.total_tokens if usage else 0,
        latency_seconds=round(latency, 3),
    )


async def _stream_openai(prompt: str) -> AsyncGenerator[str, None]:
    """Stream tokens from OpenAI."""
    from openai import AsyncOpenAI, OpenAIError

    client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY)

    try:
        stream = await client.chat.completions.create(
            model=settings.OPENAI_MODEL,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=settings.AI_MAX_TOKENS,
            temperature=settings.AI_TEMPERATURE,
            stream=True,
        )
        async for chunk in stream:
            delta = chunk.choices[0].delta.content
            if delta:
                yield delta
    except OpenAIError as exc:
        logger.error("OpenAI streaming error", error=str(exc))
        raise AIServiceException(f"OpenAI streaming error: {exc}") from exc


# ── Gemini provider ───────────────────────────────────────────────────────────

@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=2, max=10),
    reraise=True,
)
async def _call_gemini(prompt: str) -> AIResponse:
    """Call Google Gemini GenerativeAI API with retry logic."""
    try:
        import google.generativeai as genai

        genai.configure(api_key=settings.GEMINI_API_KEY)
        model = genai.GenerativeModel(settings.GEMINI_MODEL)

        start = time.monotonic()
        response = await model.generate_content_async(
            prompt,
            generation_config=genai.types.GenerationConfig(
                max_output_tokens=settings.AI_MAX_TOKENS,
                temperature=settings.AI_TEMPERATURE,
            ),
        )
        latency = time.monotonic() - start

        text = response.text
        # Gemini token counts (available in usage_metadata)
        usage = getattr(response, "usage_metadata", None)
        prompt_tokens = getattr(usage, "prompt_token_count", 0) or 0
        completion_tokens = getattr(usage, "candidates_token_count", 0) or 0

        return AIResponse(
            text=text,
            model=settings.GEMINI_MODEL,
            provider="gemini",
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=prompt_tokens + completion_tokens,
            latency_seconds=round(latency, 3),
        )
    except Exception as exc:
        logger.error("Gemini API error", error=str(exc))
        raise AIServiceException(f"Gemini error: {exc}") from exc


async def _stream_gemini(prompt: str) -> AsyncGenerator[str, None]:
    """Stream tokens from Gemini."""
    try:
        import google.generativeai as genai

        genai.configure(api_key=settings.GEMINI_API_KEY)
        model = genai.GenerativeModel(settings.GEMINI_MODEL)

        async for chunk in await model.generate_content_async(
            prompt,
            generation_config=genai.types.GenerationConfig(
                max_output_tokens=settings.AI_MAX_TOKENS,
            ),
            stream=True,
        ):
            if chunk.text:
                yield chunk.text
    except Exception as exc:
        logger.error("Gemini streaming error", error=str(exc))
        raise AIServiceException(f"Gemini streaming error: {exc}") from exc


# ── Public interface ──────────────────────────────────────────────────────────

async def get_ai_response(
    prompt: str,
    redis_client: aioredis.Redis | None = None,
    provider: str | None = None,
) -> AIResponse:
    """
    Main entry point for non-streaming AI responses.
    1. Check Redis cache first.
    2. Call the appropriate provider.
    3. Cache the result.

    Args:
        prompt:       The user's message.
        redis_client: Optional Redis client for caching.
        provider:     Override provider ("openai" or "gemini").
                      Falls back to settings.AI_PROVIDER.
    """
    active_provider = provider or settings.AI_PROVIDER
    model = settings.OPENAI_MODEL if active_provider == "openai" else settings.GEMINI_MODEL
    cache_key = _cache_key(active_provider, model, prompt)

    # ── Cache lookup ─────────────────────────────────────────
    if redis_client:
        try:
            cached = await redis_client.get(cache_key)
            if cached:
                data = json.loads(cached)
                logger.info("AI response served from cache", key=cache_key)
                return AIResponse(
                    text=data["text"],
                    model=data["model"],
                    provider=data["provider"],
                    prompt_tokens=data.get("prompt_tokens", 0),
                    completion_tokens=data.get("completion_tokens", 0),
                    total_tokens=data.get("total_tokens", 0),
                    from_cache=True,
                    latency_seconds=0.0,
                )
        except Exception as exc:
            logger.warning("Redis cache read failed", error=str(exc))

    # ── Provider call ─────────────────────────────────────────
    if active_provider == "openai":
        result = await _call_openai(prompt)
    elif active_provider == "gemini":
        result = await _call_gemini(prompt)
    else:
        raise AIServiceException(f"Unknown AI provider: {active_provider}")

    # ── Cache the result ──────────────────────────────────────
    if redis_client and result.text:
        try:
            payload = {
                "text": result.text,
                "model": result.model,
                "provider": result.provider,
                "prompt_tokens": result.prompt_tokens,
                "completion_tokens": result.completion_tokens,
                "total_tokens": result.total_tokens,
            }
            await redis_client.setex(
                cache_key,
                settings.CACHE_TTL_SECONDS,
                json.dumps(payload),
            )
        except Exception as exc:
            logger.warning("Redis cache write failed", error=str(exc))

    logger.info(
        "AI response generated",
        provider=active_provider,
        model=result.model,
        tokens=result.total_tokens,
        latency=result.latency_seconds,
    )
    return result


async def stream_ai_response(
    prompt: str,
    provider: str | None = None,
) -> AsyncGenerator[str, None]:
    """
    Stream AI response tokens.
    Used by the SSE endpoint – yields text chunks as they arrive.
    """
    active_provider = provider or settings.AI_PROVIDER

    if active_provider == "openai":
        async for chunk in _stream_openai(prompt):
            yield chunk
    elif active_provider == "gemini":
        async for chunk in _stream_gemini(prompt):
            yield chunk
    else:
        raise AIServiceException(f"Unknown AI provider: {active_provider}")
