"""
app/services/auth_service.py
─────────────────────────────
Business logic for authentication:
  • register_user    – create a new account
  • login_user       – verify credentials → issue tokens
  • refresh_tokens   – exchange refresh token for new pair
"""

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.exceptions import ConflictException, UnauthorizedException
from app.core.logging import get_logger
from app.core.security import (
    create_access_token,
    create_refresh_token,
    hash_password,
    verify_password,
    verify_refresh_token,
)
from app.models.user import User
from app.schemas.user import TokenResponse, UserRegister

logger = get_logger(__name__)


async def register_user(payload: UserRegister, db: AsyncSession) -> User:
    """
    Create a new user account.

    Raises:
        ConflictException: if email or username is already taken.
    """
    # Check for duplicate email
    existing = await db.execute(
        select(User).where(User.email == payload.email)
    )
    if existing.scalar_one_or_none():
        raise ConflictException("An account with this email already exists")

    # Check for duplicate username
    existing = await db.execute(
        select(User).where(User.username == payload.username)
    )
    if existing.scalar_one_or_none():
        raise ConflictException("This username is already taken")

    user = User(
        username=payload.username,
        email=payload.email,
        hashed_password=hash_password(payload.password),
        role="user",
        is_active=True,
        is_verified=False,
    )
    db.add(user)
    await db.flush()   # get the generated UUID without committing

    logger.info("New user registered", email=payload.email, user_id=str(user.id))
    return user


async def login_user(email: str, password: str, db: AsyncSession) -> TokenResponse:
    """
    Verify credentials and return JWT token pair.

    Raises:
        UnauthorizedException: if credentials are wrong or account is inactive.
    """
    result = await db.execute(select(User).where(User.email == email))
    user = result.scalar_one_or_none()

    if not user or not verify_password(password, user.hashed_password):
        # Use generic message to avoid leaking whether the email exists
        raise UnauthorizedException("Invalid email or password")

    if not user.is_active:
        raise UnauthorizedException("Your account has been deactivated")

    return _build_token_response(user)


async def refresh_tokens(refresh_token: str, db: AsyncSession) -> TokenResponse:
    """
    Validate a refresh token and issue a new access + refresh pair.

    Raises:
        UnauthorizedException: if token is invalid/expired.
    """
    from jose import JWTError

    try:
        payload = verify_refresh_token(refresh_token)
        user_id = payload.get("sub")
    except JWTError:
        raise UnauthorizedException("Invalid or expired refresh token")

    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()

    if not user or not user.is_active:
        raise UnauthorizedException("User not found or inactive")

    logger.info("Tokens refreshed", user_id=str(user.id))
    return _build_token_response(user)


def _build_token_response(user: User) -> TokenResponse:
    """Build the standard TokenResponse from a User ORM object."""
    return TokenResponse(
        access_token=create_access_token(str(user.id), role=user.role),
        refresh_token=create_refresh_token(str(user.id)),
        token_type="bearer",
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
    )
