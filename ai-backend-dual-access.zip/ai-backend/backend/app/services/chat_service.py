"""
app/services/chat_service.py
─────────────────────────────
Orchestrates the full chat flow:
  1. Create a ChatMessage row (status = "streaming" or pending)
  2. Call the AI service (with caching)
  3. Update the row with the response + token counts
  4. Update APIUsage stats
"""

import uuid
from datetime import date

import redis.asyncio as aioredis
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import AIServiceException, NotFoundException
from app.core.logging import get_logger
from app.models.api_usage import APIUsage
from app.models.chat import ChatMessage
from app.models.user import User
from app.services.ai_service import AIResponse, get_ai_response

logger = get_logger(__name__)


async def create_chat_message(
    user: User,
    prompt: str,
    db: AsyncSession,
    redis_client: aioredis.Redis | None = None,
    provider: str | None = None,
) -> ChatMessage:
    """
    Full chat pipeline:
      prompt → AI → saved to DB → usage tracked → return ChatMessage.

    Args:
        user:         Authenticated user ORM object.
        prompt:       The user's message text.
        db:           Async DB session.
        redis_client: Optional Redis for response caching.
        provider:     Override AI provider.

    Returns:
        Populated ChatMessage ORM object.
    """
    # ── 1. Persist the prompt immediately ────────────────────
    message = ChatMessage(
        user_id=user.id,
        prompt=prompt,
        status="processing",
    )
    db.add(message)
    await db.flush()   # assign UUID without committing

    try:
        # ── 2. Call AI ────────────────────────────────────────
        ai_result: AIResponse = await get_ai_response(
            prompt=prompt,
            redis_client=redis_client,
            provider=provider,
        )

        # ── 3. Update message with response ───────────────────
        message.response = ai_result.text
        message.model_used = ai_result.model
        message.provider = ai_result.provider
        message.prompt_tokens = ai_result.prompt_tokens
        message.completion_tokens = ai_result.completion_tokens
        message.total_tokens = ai_result.total_tokens
        message.latency_seconds = ai_result.latency_seconds
        message.from_cache = ai_result.from_cache
        message.status = "completed"

        # ── 4. Track API usage (upsert by user+date+provider+model) ─
        if not ai_result.from_cache:
            await _upsert_api_usage(
                user_id=user.id,
                provider=ai_result.provider,
                model=ai_result.model,
                prompt_tokens=ai_result.prompt_tokens,
                completion_tokens=ai_result.completion_tokens,
                total_tokens=ai_result.total_tokens,
                db=db,
            )

        await db.flush()
        logger.info(
            "Chat message completed",
            message_id=str(message.id),
            user_id=str(user.id),
            tokens=ai_result.total_tokens,
            from_cache=ai_result.from_cache,
        )

    except AIServiceException as exc:
        # Store the error in the DB so the user/admin can inspect it
        message.status = "error"
        message.error_message = str(exc)
        await db.flush()
        logger.error(
            "Chat AI error stored",
            message_id=str(message.id),
            error=str(exc),
        )
        raise  # re-raise so the endpoint can return 503

    return message


async def get_user_chat_history(
    user_id: uuid.UUID,
    db: AsyncSession,
    page: int = 1,
    page_size: int = 20,
) -> tuple[list[ChatMessage], int]:
    """
    Return paginated chat history for a user.

    Returns:
        (list_of_messages, total_count)
    """
    offset = (page - 1) * page_size

    # Total count
    count_result = await db.execute(
        select(func.count()).where(ChatMessage.user_id == user_id)
    )
    total = count_result.scalar_one()

    # Paginated results – newest first
    result = await db.execute(
        select(ChatMessage)
        .where(ChatMessage.user_id == user_id)
        .order_by(ChatMessage.created_at.desc())
        .offset(offset)
        .limit(page_size)
    )
    messages = result.scalars().all()

    return list(messages), total


async def get_all_chats(
    db: AsyncSession,
    page: int = 1,
    page_size: int = 20,
) -> tuple[list[ChatMessage], int]:
    """Admin: return all chat messages across all users, paginated."""
    offset = (page - 1) * page_size

    count_result = await db.execute(select(func.count(ChatMessage.id)))
    total = count_result.scalar_one()

    result = await db.execute(
        select(ChatMessage)
        .order_by(ChatMessage.created_at.desc())
        .offset(offset)
        .limit(page_size)
    )
    return list(result.scalars().all()), total


async def delete_chat_message(
    message_id: uuid.UUID,
    user_id: uuid.UUID,
    db: AsyncSession,
    is_admin: bool = False,
) -> None:
    """Delete a chat message. Users can only delete their own."""
    result = await db.execute(
        select(ChatMessage).where(ChatMessage.id == message_id)
    )
    message = result.scalar_one_or_none()

    if not message:
        raise NotFoundException("Chat message")

    if not is_admin and message.user_id != user_id:
        from app.core.exceptions import ForbiddenException
        raise ForbiddenException("You can only delete your own messages")

    await db.delete(message)


# ── Internal helper ───────────────────────────────────────────────────────────

async def _upsert_api_usage(
    user_id: uuid.UUID,
    provider: str,
    model: str,
    prompt_tokens: int,
    completion_tokens: int,
    total_tokens: int,
    db: AsyncSession,
) -> None:
    """Increment usage counters for today's row (insert if first call today)."""
    today = date.today()

    result = await db.execute(
        select(APIUsage).where(
            APIUsage.user_id == user_id,
            APIUsage.usage_date == today,
            APIUsage.provider == provider,
            APIUsage.model == model,
        )
    )
    usage = result.scalar_one_or_none()

    if usage:
        usage.total_prompt_tokens += prompt_tokens
        usage.total_completion_tokens += completion_tokens
        usage.total_tokens += total_tokens
        usage.request_count += 1
    else:
        usage = APIUsage(
            user_id=user_id,
            usage_date=today,
            provider=provider,
            model=model,
            total_prompt_tokens=prompt_tokens,
            total_completion_tokens=completion_tokens,
            total_tokens=total_tokens,
            request_count=1,
        )
        db.add(usage)
