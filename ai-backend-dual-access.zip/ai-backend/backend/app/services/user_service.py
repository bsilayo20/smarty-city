"""
app/services/user_service.py
──────────────────────────────
User management business logic:
  • get_user_by_id / email
  • update_user profile
  • change password
  • admin: list / delete users
"""

import uuid

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import (
    ConflictException,
    ForbiddenException,
    NotFoundException,
    UnauthorizedException,
)
from app.core.logging import get_logger
from app.core.security import hash_password, verify_password
from app.models.user import User
from app.schemas.user import PasswordChange, UserUpdate

logger = get_logger(__name__)


async def get_user_by_id(user_id: uuid.UUID, db: AsyncSession) -> User:
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise NotFoundException("User")
    return user


async def get_user_by_email(email: str, db: AsyncSession) -> User | None:
    result = await db.execute(select(User).where(User.email == email))
    return result.scalar_one_or_none()


async def update_user(
    user: User,
    payload: UserUpdate,
    db: AsyncSession,
) -> User:
    """Update username and/or email. Checks for conflicts first."""

    if payload.email and payload.email != user.email:
        existing = await get_user_by_email(payload.email, db)
        if existing:
            raise ConflictException("Email already in use")
        user.email = payload.email

    if payload.username and payload.username != user.username:
        result = await db.execute(
            select(User).where(User.username == payload.username)
        )
        if result.scalar_one_or_none():
            raise ConflictException("Username already taken")
        user.username = payload.username

    await db.flush()
    logger.info("User profile updated", user_id=str(user.id))
    return user


async def change_password(
    user: User,
    payload: PasswordChange,
    db: AsyncSession,
) -> None:
    """Verify current password then set new one."""
    if not verify_password(payload.current_password, user.hashed_password):
        raise UnauthorizedException("Current password is incorrect")

    if payload.current_password == payload.new_password:
        raise ConflictException("New password must be different from current password")

    user.hashed_password = hash_password(payload.new_password)
    await db.flush()
    logger.info("Password changed", user_id=str(user.id))


# ── Admin operations ──────────────────────────────────────────────────────────

async def list_users(
    db: AsyncSession,
    page: int = 1,
    page_size: int = 20,
    role: str | None = None,
) -> tuple[list[User], int]:
    """Return paginated list of all users."""
    offset = (page - 1) * page_size

    query = select(User)
    count_query = select(func.count(User.id))

    if role:
        query = query.where(User.role == role)
        count_query = count_query.where(User.role == role)

    total = (await db.execute(count_query)).scalar_one()
    users = (
        await db.execute(
            query.order_by(User.created_at.desc()).offset(offset).limit(page_size)
        )
    ).scalars().all()

    return list(users), total


async def admin_delete_user(
    user_id: uuid.UUID,
    requesting_admin: User,
    db: AsyncSession,
) -> None:
    """Admin deletes any user. Cannot self-delete."""
    if requesting_admin.id == user_id:
        raise ForbiddenException("Admins cannot delete their own account")

    user = await get_user_by_id(user_id, db)
    await db.delete(user)
    logger.info(
        "User deleted by admin",
        deleted_user_id=str(user_id),
        admin_id=str(requesting_admin.id),
    )


async def toggle_user_active(
    user_id: uuid.UUID,
    is_active: bool,
    db: AsyncSession,
) -> User:
    """Admin activates / deactivates a user."""
    user = await get_user_by_id(user_id, db)
    user.is_active = is_active
    await db.flush()
    logger.info(
        "User active status changed",
        user_id=str(user_id),
        is_active=is_active,
    )
    return user
