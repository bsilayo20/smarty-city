"""
app/core/security.py
────────────────────
All authentication primitives:
  • bcrypt password hashing / verification
  • JWT access-token creation
  • JWT refresh-token creation
  • Token decoding & validation
"""

from datetime import datetime, timedelta, timezone
from typing import Any

from jose import JWTError, jwt
from passlib.context import CryptContext

from app.core.config import settings

# ── bcrypt context ──────────────────────────────────────────────────────────
# deprecated="auto" means old hashes are upgraded on next login automatically
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


# ── Password Helpers ────────────────────────────────────────────────────────

def hash_password(plain_password: str) -> str:
    """Return a bcrypt hash of the plain-text password."""
    return pwd_context.hash(plain_password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Return True if the plain password matches the stored hash."""
    return pwd_context.verify(plain_password, hashed_password)


# ── Token Helpers ───────────────────────────────────────────────────────────

def _create_token(
    subject: str | Any,
    token_type: str,
    expires_delta: timedelta,
    extra_claims: dict | None = None,
) -> str:
    """
    Internal helper – builds and signs a JWT.

    Args:
        subject:       The user identifier (usually user UUID as str).
        token_type:    "access" or "refresh" – stored in the `type` claim.
        expires_delta: How long until the token expires.
        extra_claims:  Any additional claims to embed (e.g. role).
    """
    now = datetime.now(timezone.utc)
    payload: dict[str, Any] = {
        "sub": str(subject),
        "type": token_type,
        "iat": now,
        "exp": now + expires_delta,
    }
    if extra_claims:
        payload.update(extra_claims)

    return jwt.encode(payload, settings.SECRET_KEY, algorithm=settings.ALGORITHM)


def create_access_token(
    subject: str | Any,
    role: str = "user",
    expires_delta: timedelta | None = None,
) -> str:
    """
    Create a short-lived JWT access token.
    Default expiry: ACCESS_TOKEN_EXPIRE_MINUTES from settings.
    """
    delta = expires_delta or timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    return _create_token(subject, "access", delta, {"role": role})


def create_refresh_token(
    subject: str | Any,
    expires_delta: timedelta | None = None,
) -> str:
    """
    Create a long-lived JWT refresh token.
    Default expiry: REFRESH_TOKEN_EXPIRE_DAYS from settings.
    """
    delta = expires_delta or timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS)
    return _create_token(subject, "refresh", delta)


def decode_token(token: str) -> dict[str, Any]:
    """
    Decode and validate a JWT.

    Raises:
        JWTError: If the token is expired, tampered with, or malformed.
    """
    return jwt.decode(
        token,
        settings.SECRET_KEY,
        algorithms=[settings.ALGORITHM],
    )


def verify_access_token(token: str) -> dict[str, Any]:
    """
    Decode token and confirm it is an *access* token.
    Raises JWTError if type != "access".
    """
    payload = decode_token(token)
    if payload.get("type") != "access":
        raise JWTError("Token is not an access token")
    return payload


def verify_refresh_token(token: str) -> dict[str, Any]:
    """
    Decode token and confirm it is a *refresh* token.
    Raises JWTError if type != "refresh".
    """
    payload = decode_token(token)
    if payload.get("type") != "refresh":
        raise JWTError("Token is not a refresh token")
    return payload
