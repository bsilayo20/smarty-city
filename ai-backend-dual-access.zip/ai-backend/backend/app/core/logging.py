"""
app/core/logging.py
───────────────────
Configures structlog for structured, JSON-friendly logging.
  • In production  → JSON lines (machine-parseable by Datadog, Loki, etc.)
  • In development → coloured, human-readable console output
"""

import logging
import sys

import structlog

from app.core.config import settings


def setup_logging() -> None:
    """
    Call once at application startup to wire up structlog + stdlib logging.
    All loggers created after this point will use the same pipeline.
    """

    # ── Shared processors (run for every log event) ─────────────────────────
    shared_processors: list = [
        structlog.contextvars.merge_contextvars,          # request-scoped context
        structlog.stdlib.add_log_level,                   # "level": "info"
        structlog.stdlib.add_logger_name,                 # "logger": "app.services.chat"
        structlog.processors.TimeStamper(fmt="iso"),      # "timestamp": "2024-..."
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
    ]

    # ── Choose renderer based on LOG_FORMAT ─────────────────────────────────
    if settings.LOG_FORMAT == "json":
        renderer = structlog.processors.JSONRenderer()
    else:
        renderer = structlog.dev.ConsoleRenderer(colors=True)

    # ── Configure structlog ─────────────────────────────────────────────────
    structlog.configure(
        processors=shared_processors + [
            structlog.stdlib.ProcessorFormatter.wrap_for_formatter,
        ],
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )

    # ── Configure stdlib so third-party libs (uvicorn, sqlalchemy) also go
    #    through structlog ─────────────────────────────────────────────────
    formatter = structlog.stdlib.ProcessorFormatter(
        foreign_pre_chain=shared_processors,
        processors=[
            structlog.stdlib.ProcessorFormatter.remove_processors_meta,
            renderer,
        ],
    )

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(formatter)

    root_logger = logging.getLogger()
    root_logger.handlers = [handler]
    root_logger.setLevel(settings.LOG_LEVEL.upper())

    # Silence noisy third-party loggers
    for noisy in ["uvicorn.access", "passlib"]:
        logging.getLogger(noisy).setLevel(logging.WARNING)


def get_logger(name: str = __name__) -> structlog.stdlib.BoundLogger:
    """Return a structlog logger bound to the given name."""
    return structlog.get_logger(name)
