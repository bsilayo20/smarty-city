"""
app/core/dependencies.py
────────────────────────
Reusable FastAPI dependencies injected into route handlers via Depends().

  get_db          → yields an async SQLAlchemy session
  get_redis       → yields a Redis client
  get_current_user     → extracts & validates JWT, returns User model
  get_current_admin    → same but asserts role == "admin"
  require_role(...)    → factory for role-based guards
"""

from typing import AsyncGenerator

import redis.asyncio as aioredis
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.logging import get_logger
from app.core.security import verify_access_token
from app.db.session import AsyncSessionLocal

logger = get_logger(__name__)

# ── HTTP Bearer scheme (reads the Authorization: Bearer <token> header) ─────
bearer_scheme = HTTPBearer(auto_error=True)


# ── Database session ─────────────────────────────────────────────────────────

async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """
    Yield an async database session for the duration of a request,
    then commit (or rollback on error) and close.
    """
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


# ── Redis client ─────────────────────────────────────────────────────────────

_redis_pool: aioredis.Redis | None = None


async def get_redis() -> AsyncGenerator[aioredis.Redis, None]:
    """
    Return the shared async Redis client (connection pool is reused).
    Falls back gracefully if Redis is unavailable so the app still starts.
    """
    global _redis_pool
    if _redis_pool is None:
        try:
            _redis_pool = aioredis.from_url(
                settings.REDIS_URL,
                encoding="utf-8",
                decode_responses=True,
                socket_connect_timeout=2,
            )
        except Exception as exc:
            logger.warning("Redis unavailable – caching disabled", error=str(exc))
            yield None
            return
    yield _redis_pool


# ── JWT Authentication dependencies ──────────────────────────────────────────

async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme),
    db: AsyncSession = Depends(get_db),
):
    """
    Validate the Bearer JWT and return the corresponding User ORM object.
    Raises 401 if token is missing, invalid, or the user no longer exists.
    """
    # Import here to avoid circular imports
    from app.models.user import User
    from sqlalchemy import select

    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )

    try:
        payload = verify_access_token(credentials.credentials)
        user_id: str = payload.get("sub")
        if user_id is None:
            raise credentials_exception
    except JWTError as exc:
        logger.warning("JWT validation failed", error=str(exc))
        raise credentials_exception

    # Fetch user from DB
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()

    if user is None:
        raise credentials_exception

    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account is inactive",
        )

    return user


async def get_current_admin(current_user=Depends(get_current_user)):
    """
    Extends get_current_user – additionally asserts the user has admin role.
    Raises 403 if role is not 'admin'.
    """
    if current_user.role != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin privileges required",
        )
    return current_user


def require_role(*roles: str):
    """
    Factory dependency – allow multiple roles.

    Usage:
        @router.get("/endpoint")
        async def handler(user = Depends(require_role("admin", "moderator"))):
            ...
    """
    async def _check_role(current_user=Depends(get_current_user)):
        if current_user.role not in roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Required role: {', '.join(roles)}",
            )
        return current_user

    return _check_role
