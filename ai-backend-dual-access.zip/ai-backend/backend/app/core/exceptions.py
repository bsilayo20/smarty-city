"""
app/core/exceptions.py
──────────────────────
Centralised exception definitions + FastAPI exception handlers.
Register all handlers in main.py via register_exception_handlers(app).
"""

from fastapi import FastAPI, HTTPException, Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from pydantic import ValidationError

from app.core.logging import get_logger

logger = get_logger(__name__)


# ── Custom application exceptions ────────────────────────────────────────────

class AppException(Exception):
    """Base class for all application-specific exceptions."""
    def __init__(
        self,
        status_code: int = status.HTTP_500_INTERNAL_SERVER_ERROR,
        detail: str = "An unexpected error occurred",
        error_code: str = "INTERNAL_ERROR",
    ):
        self.status_code = status_code
        self.detail = detail
        self.error_code = error_code
        super().__init__(detail)


class NotFoundException(AppException):
    def __init__(self, resource: str = "Resource"):
        super().__init__(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"{resource} not found",
            error_code="NOT_FOUND",
        )


class UnauthorizedException(AppException):
    def __init__(self, detail: str = "Authentication required"):
        super().__init__(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=detail,
            error_code="UNAUTHORIZED",
        )


class ForbiddenException(AppException):
    def __init__(self, detail: str = "You don't have permission"):
        super().__init__(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=detail,
            error_code="FORBIDDEN",
        )


class ConflictException(AppException):
    def __init__(self, detail: str = "Resource already exists"):
        super().__init__(
            status_code=status.HTTP_409_CONFLICT,
            detail=detail,
            error_code="CONFLICT",
        )


class AIServiceException(AppException):
    def __init__(self, detail: str = "AI service is temporarily unavailable"):
        super().__init__(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=detail,
            error_code="AI_SERVICE_ERROR",
        )


class RateLimitException(AppException):
    def __init__(self):
        super().__init__(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Rate limit exceeded. Please wait before retrying.",
            error_code="RATE_LIMIT_EXCEEDED",
        )


# ── Response builders ────────────────────────────────────────────────────────

def _error_response(
    status_code: int,
    error_code: str,
    detail: str | list,
    request: Request | None = None,
) -> JSONResponse:
    """Standardised error envelope returned to clients."""
    body = {
        "success": False,
        "error": {
            "code": error_code,
            "detail": detail,
        },
    }
    if request:
        body["path"] = request.url.path

    return JSONResponse(status_code=status_code, content=body)


# ── Exception handlers ───────────────────────────────────────────────────────

async def app_exception_handler(request: Request, exc: AppException) -> JSONResponse:
    logger.warning(
        "Application exception",
        path=request.url.path,
        error_code=exc.error_code,
        detail=exc.detail,
    )
    return _error_response(exc.status_code, exc.error_code, exc.detail, request)


async def http_exception_handler(request: Request, exc: HTTPException) -> JSONResponse:
    logger.warning(
        "HTTP exception",
        path=request.url.path,
        status_code=exc.status_code,
        detail=exc.detail,
    )
    return _error_response(exc.status_code, "HTTP_ERROR", exc.detail, request)


async def validation_exception_handler(
    request: Request, exc: RequestValidationError
) -> JSONResponse:
    """Format Pydantic validation errors into a clean list."""
    errors = [
        {
            "field": ".".join(str(loc) for loc in error["loc"]),
            "message": error["msg"],
            "type": error["type"],
        }
        for error in exc.errors()
    ]
    logger.info("Validation error", path=request.url.path, errors=errors)
    return _error_response(
        status.HTTP_422_UNPROCESSABLE_ENTITY,
        "VALIDATION_ERROR",
        errors,
        request,
    )


async def unhandled_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    """Catch-all for any unhandled exceptions – log full traceback."""
    logger.exception(
        "Unhandled exception",
        path=request.url.path,
        exc_info=exc,
    )
    return _error_response(
        status.HTTP_500_INTERNAL_SERVER_ERROR,
        "INTERNAL_ERROR",
        "An internal server error occurred",
        request,
    )


# ── Registration helper ──────────────────────────────────────────────────────

def register_exception_handlers(app: FastAPI) -> None:
    """Call this once in main.py to attach all handlers to the FastAPI app."""
    app.add_exception_handler(AppException, app_exception_handler)
    app.add_exception_handler(HTTPException, http_exception_handler)
    app.add_exception_handler(RequestValidationError, validation_exception_handler)
    app.add_exception_handler(Exception, unhandled_exception_handler)
