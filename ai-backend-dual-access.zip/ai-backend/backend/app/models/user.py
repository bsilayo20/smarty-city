"""
app/models/user.py
──────────────────
User table – stores credentials, role, and activity status.

Relationships:
  • User  →  ChatMessage   (one-to-many)
  • User  →  APIUsage      (one-to-many)
"""

from typing import TYPE_CHECKING, List

from sqlalchemy import Boolean, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base
from app.models.base import TimestampMixin, UUIDMixin

if TYPE_CHECKING:
    from app.models.chat import ChatMessage
    from app.models.api_usage import APIUsage


class User(UUIDMixin, TimestampMixin, Base):
    """Represents a registered user."""

    __tablename__ = "users"

    # ── Identity ──────────────────────────────────────────────
    username: Mapped[str] = mapped_column(
        String(50), unique=True, index=True, nullable=False
    )
    email: Mapped[str] = mapped_column(
        String(255), unique=True, index=True, nullable=False
    )
    hashed_password: Mapped[str] = mapped_column(String(255), nullable=False)

    # ── Role ──────────────────────────────────────────────────
    # Stored as a plain string: "user" | "admin"
    # For more roles, switch to a separate Role table.
    role: Mapped[str] = mapped_column(String(20), default="user", nullable=False)

    # ── Status ────────────────────────────────────────────────
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    is_verified: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    # ── Relationships ─────────────────────────────────────────
    messages: Mapped[List["ChatMessage"]] = relationship(
        "ChatMessage",
        back_populates="user",
        cascade="all, delete-orphan",   # deleting a user deletes their chats
        lazy="select",
    )
    api_usages: Mapped[List["APIUsage"]] = relationship(
        "APIUsage",
        back_populates="user",
        cascade="all, delete-orphan",
        lazy="select",
    )

    def __repr__(self) -> str:
        return f"<User id={self.id} email={self.email} role={self.role}>"
