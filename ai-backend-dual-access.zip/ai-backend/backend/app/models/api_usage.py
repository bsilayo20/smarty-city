"""
app/models/api_usage.py
───────────────────────
Tracks cumulative AI API usage per user for admin dashboards
and cost monitoring.
"""

import uuid

from sqlalchemy import Date, Float, ForeignKey, Integer, String, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base
from app.models.base import TimestampMixin, UUIDMixin


class APIUsage(UUIDMixin, TimestampMixin, Base):
    """
    One row per (user, date, provider) combination.
    Updated (not inserted) each time a user calls the AI.
    """

    __tablename__ = "api_usage"

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    # Date bucket – makes daily/monthly rollups trivial
    usage_date: Mapped[Date] = mapped_column(
        Date, server_default=func.current_date(), nullable=False
    )

    provider: Mapped[str] = mapped_column(String(50), nullable=False)   # openai / gemini
    model: Mapped[str] = mapped_column(String(100), nullable=False)

    # Cumulative token counts for this (user, date, provider, model)
    total_prompt_tokens: Mapped[int] = mapped_column(Integer, default=0)
    total_completion_tokens: Mapped[int] = mapped_column(Integer, default=0)
    total_tokens: Mapped[int] = mapped_column(Integer, default=0)
    request_count: Mapped[int] = mapped_column(Integer, default=0)

    # Estimated cost in USD (calculated by the service layer)
    estimated_cost_usd: Mapped[float] = mapped_column(Float, default=0.0)

    # Relationship back to user
    user = relationship("User", back_populates="api_usages")

    def __repr__(self) -> str:
        return (
            f"<APIUsage user={self.user_id} date={self.usage_date} "
            f"tokens={self.total_tokens}>"
        )
