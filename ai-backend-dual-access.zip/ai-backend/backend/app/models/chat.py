"""
app/models/chat.py
──────────────────
ChatMessage table – persists every AI conversation turn.

Each row is ONE exchange:  user prompt  →  AI response.
"""

import uuid
from typing import TYPE_CHECKING

from sqlalchemy import Float, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base
from app.models.base import TimestampMixin, UUIDMixin

if TYPE_CHECKING:
    from app.models.user import User


class ChatMessage(UUIDMixin, TimestampMixin, Base):
    """A single chat exchange between a user and the AI."""

    __tablename__ = "chat_messages"

    # ── Foreign key ───────────────────────────────────────────
    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    # ── Content ───────────────────────────────────────────────
    prompt: Mapped[str] = mapped_column(Text, nullable=False)
    response: Mapped[str] = mapped_column(Text, nullable=True)  # null while streaming

    # ── AI metadata ───────────────────────────────────────────
    model_used: Mapped[str] = mapped_column(String(100), nullable=True)
    provider: Mapped[str] = mapped_column(String(50), nullable=True)   # "openai"/"gemini"

    # Token counts (populated after response)
    prompt_tokens: Mapped[int] = mapped_column(Integer, default=0, nullable=True)
    completion_tokens: Mapped[int] = mapped_column(Integer, default=0, nullable=True)
    total_tokens: Mapped[int] = mapped_column(Integer, default=0, nullable=True)

    # Latency in seconds
    latency_seconds: Mapped[float] = mapped_column(Float, nullable=True)

    # Whether the response was served from Redis cache
    from_cache: Mapped[bool] = mapped_column(default=False, nullable=False)

    # Status: "completed" | "error" | "streaming"
    status: Mapped[str] = mapped_column(String(20), default="completed", nullable=False)

    # Error message if status == "error"
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)

    # ── Relationship ──────────────────────────────────────────
    user: Mapped["User"] = relationship("User", back_populates="messages")

    def __repr__(self) -> str:
        return f"<ChatMessage id={self.id} user_id={self.user_id} status={self.status}>"
