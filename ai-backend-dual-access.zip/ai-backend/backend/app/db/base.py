"""
app/db/base.py
──────────────
Declarative base shared by all ORM models.
Import Base here (not from individual models) to avoid circular imports.
"""

from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    """
    All ORM models inherit from this class.
    SQLAlchemy uses it to track the metadata (table names, columns, etc.)
    needed for migrations and schema creation.
    """
    pass
