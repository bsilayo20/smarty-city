"""
app/db/init_db.py
─────────────────
Called once at application startup to:
  1. Create all tables (in non-migration mode / dev).
  2. Seed the first admin user if none exists.
"""

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.logging import get_logger
from app.core.security import hash_password

logger = get_logger(__name__)


async def init_db(db: AsyncSession) -> None:
    """
    Seed the database with initial data.
    Safe to call multiple times – checks before inserting.
    """
    await _create_first_admin(db)


async def _create_first_admin(db: AsyncSession) -> None:
    """Create the first admin user if no admin exists yet."""
    # Import here to avoid circular imports at module load
    from app.models.user import User

    result = await db.execute(
        select(User).where(User.role == "admin").limit(1)
    )
    existing_admin = result.scalar_one_or_none()

    if existing_admin:
        logger.info("Admin user already exists, skipping seed")
        return

    admin = User(
        username=settings.FIRST_ADMIN_USERNAME,
        email=settings.FIRST_ADMIN_EMAIL,
        hashed_password=hash_password(settings.FIRST_ADMIN_PASSWORD),
        role="admin",
        is_active=True,
    )
    db.add(admin)
    await db.commit()

    logger.info(
        "First admin user created",
        email=settings.FIRST_ADMIN_EMAIL,
        username=settings.FIRST_ADMIN_USERNAME,
    )
