"""
app/db/session.py
─────────────────
Creates the async SQLAlchemy engine and session factory.
All database I/O in the app goes through AsyncSession.
"""

from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.pool import NullPool

from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)

# ── Engine ───────────────────────────────────────────────────────────────────
# NullPool is used in async contexts to avoid connection-pool issues
# when the app runs inside Docker / multiple workers.
engine: AsyncEngine = create_async_engine(
    settings.DATABASE_URL,
    echo=settings.DEBUG,          # log all SQL when DEBUG=True
    future=True,
    pool_pre_ping=True,           # test connections before use
    pool_size=10,                 # max persistent connections
    max_overflow=20,              # extra connections under load
    pool_recycle=3600,            # recycle connections every hour
)

# ── Session factory ───────────────────────────────────────────────────────────
AsyncSessionLocal: async_sessionmaker[AsyncSession] = async_sessionmaker(
    bind=engine,
    class_=AsyncSession,
    expire_on_commit=False,       # objects stay usable after commit
    autoflush=True,
    autocommit=False,
)


async def check_db_connection() -> bool:
    """Health-check helper – returns True if DB is reachable."""
    try:
        async with engine.connect() as conn:
            await conn.execute(__import__("sqlalchemy").text("SELECT 1"))
        return True
    except Exception as exc:
        logger.error("Database health check failed", error=str(exc))
        return False
