#!/bin/bash
# ═══════════════════════════════════════════════════════════
#  certbot-setup.sh
#  Obtains a FREE Let's Encrypt SSL certificate for your domain.
#  Requires: a real domain pointing to your server's public IP.
#
#  Usage: chmod +x certbot-setup.sh && ./certbot-setup.sh yourdomain.com
# ═══════════════════════════════════════════════════════════

set -e

DOMAIN=${1:-""}

if [ -z "$DOMAIN" ]; then
    echo "Usage: ./certbot-setup.sh yourdomain.com"
    echo "Example: ./certbot-setup.sh api.myapp.com"
    exit 1
fi

GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}[Certbot]${NC} Setting up Let's Encrypt for: ${DOMAIN}"

# Install certbot
sudo apt update
sudo apt install -y certbot

# Create webroot for ACME challenge
mkdir -p nginx/certbot/www

# Stop nginx temporarily (port 80 must be free)
docker compose stop nginx 2>/dev/null || true

# Obtain certificate
sudo certbot certonly \
    --standalone \
    --preferred-challenges http \
    --email admin@${DOMAIN} \
    --agree-tos \
    --no-eff-email \
    -d ${DOMAIN}

# Update nginx.conf to use Let's Encrypt certs
sed -i "s|server_name _;|server_name ${DOMAIN};|g" nginx/nginx.conf
sed -i "s|# ssl_certificate     /etc/letsencrypt|ssl_certificate     /etc/letsencrypt|g" nginx/nginx.conf
sed -i "s|# ssl_certificate_key /etc/letsencrypt|ssl_certificate_key /etc/letsencrypt|g" nginx/nginx.conf
sed -i "s|ssl_certificate     /etc/nginx/ssl/cert.pem;|# ssl_certificate     /etc/nginx/ssl/cert.pem;|g" nginx/nginx.conf
sed -i "s|ssl_certificate_key /etc/nginx/ssl/key.pem;|# ssl_certificate_key /etc/nginx/ssl/key.pem;|g" nginx/nginx.conf

# Update CORS in .env
echo ""
echo -e "${BLUE}[Action Required]${NC} Add your domain to CORS_ORIGINS in backend/.env:"
echo "  CORS_ORIGINS=https://${DOMAIN},http://localhost:3000"

# Set up auto-renewal cron job
(crontab -l 2>/dev/null; echo "0 12 * * * certbot renew --quiet && docker compose exec nginx nginx -s reload") | crontab -

echo -e "${GREEN}[OK]${NC} Let's Encrypt certificate installed!"
echo "     Certificate auto-renews every 90 days via cron."
echo ""
echo "  Now restart nginx:"
echo "  docker compose restart nginx"
echo ""
echo "  Your API will be live at: https://${DOMAIN}"
