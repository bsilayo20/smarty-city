#!/bin/bash
# ═══════════════════════════════════════════════════════════
#  setup.sh  –  One-command setup script for Ubuntu
#  Usage: chmod +x setup.sh && ./setup.sh
# ═══════════════════════════════════════════════════════════

set -e  # Exit immediately on any error

# ── Colors ────────────────────────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'  # No Color

info()    { echo -e "${BLUE}[INFO]${NC} $1"; }
success() { echo -e "${GREEN}[OK]${NC} $1"; }
warn()    { echo -e "${YELLOW}[WARN]${NC} $1"; }
error()   { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║      AI Backend API — Setup Script       ║"
echo "╚══════════════════════════════════════════╝"
echo ""

# ── Check we're in the right directory ───────────────────────────────────────
if [ ! -f "docker-compose.yml" ]; then
    error "Run this script from the ai-backend/ project root (where docker-compose.yml is)"
fi

# ── Check Docker is installed ─────────────────────────────────────────────────
if ! command -v docker &> /dev/null; then
    error "Docker is not installed. Follow the README.md Step 3."
fi
success "Docker found: $(docker --version)"

# ── Check .env exists ─────────────────────────────────────────────────────────
if [ ! -f "backend/.env" ]; then
    info "Copying .env.example → .env"
    cp backend/.env.example backend/.env
    warn "⚠️  Please edit backend/.env with your API keys before continuing!"
    warn "    Minimum required: SECRET_KEY, OPENAI_API_KEY or GEMINI_API_KEY, POSTGRES_PASSWORD"
    echo ""
    read -p "Press ENTER after you have edited backend/.env ..."
fi
success ".env file found"

# ── Generate SECRET_KEY if still default ─────────────────────────────────────
if grep -q "your_super_secret_key" backend/.env; then
    info "Generating a new SECRET_KEY..."
    NEW_KEY=$(openssl rand -hex 32)
    # Replace in .env
    sed -i "s/your_super_secret_key_change_this_in_production_minimum_32_chars/$NEW_KEY/" backend/.env
    success "SECRET_KEY auto-generated"
fi

# ── Build and start services ───────────────────────────────────────────────────
info "Building Docker images (this may take 2-3 minutes the first time)..."
docker compose build

info "Starting services (postgres, redis)..."
docker compose up -d postgres redis

info "Waiting for PostgreSQL to be ready..."
sleep 5

# ── Run migrations ─────────────────────────────────────────────────────────────
info "Running database migrations..."
docker compose run --rm migrate

success "Database migrations complete"

# ── Start the API ──────────────────────────────────────────────────────────────
info "Starting the API server..."
docker compose up -d api

# ── Wait for API to be healthy ─────────────────────────────────────────────────
info "Waiting for API to be healthy..."
for i in {1..12}; do
    if curl -sf http://localhost:8000/api/v1/health > /dev/null 2>&1; then
        success "API is healthy!"
        break
    fi
    sleep 5
    echo "  Attempt $i/12..."
done

# ── Show status ────────────────────────────────────────────────────────────────
echo ""
echo "╔══════════════════════════════════════════╗"
echo "║           Setup Complete! 🎉             ║"
echo "╚══════════════════════════════════════════╝"
echo ""
echo "  📖 Swagger UI  →  http://localhost:8000/docs"
echo "  🔍 Health      →  http://localhost:8000/api/v1/health"
echo "  🛢  pgAdmin     →  docker compose --profile tools up -d pgadmin"
echo "                     then: http://localhost:5050"
echo ""
echo "  Default admin login:"
echo "    Email:    admin@example.com"
echo "    Password: Admin@123456"
echo "    (Change these in backend/.env → FIRST_ADMIN_EMAIL / FIRST_ADMIN_PASSWORD)"
echo ""
echo "  Useful commands:"
echo "    docker compose logs -f api       # Watch API logs"
echo "    docker compose down              # Stop everything"
echo "    docker compose ps                # Check status"
echo ""
