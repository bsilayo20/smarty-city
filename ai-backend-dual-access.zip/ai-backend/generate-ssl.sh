#!/bin/bash
# ═══════════════════════════════════════════════════════════
#  generate-ssl.sh
#  Generates a self-signed SSL certificate for LAN / dev use.
#  For production with a real domain, use Let's Encrypt instead.
#
#  Usage: chmod +x generate-ssl.sh && ./generate-ssl.sh
# ═══════════════════════════════════════════════════════════

set -e

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${BLUE}[SSL]${NC} Generating self-signed certificate..."

# Create directory for SSL certificates
mkdir -p nginx/ssl

# Detect the machine's LAN IP automatically
LAN_IP=$(hostname -I | awk '{print $1}')
echo -e "${BLUE}[SSL]${NC} Detected LAN IP: ${LAN_IP}"

# Generate a 2-year self-signed certificate
# The certificate will be valid for:
#   - localhost
#   - 127.0.0.1
#   - Your current LAN IP
openssl req -x509 \
    -newkey rsa:4096 \
    -keyout nginx/ssl/key.pem \
    -out nginx/ssl/cert.pem \
    -days 730 \
    -nodes \
    -subj "/C=US/ST=Dev/L=Local/O=AI Backend/CN=${LAN_IP}" \
    -addext "subjectAltName=IP:${LAN_IP},IP:127.0.0.1,DNS:localhost"

chmod 600 nginx/ssl/key.pem
chmod 644 nginx/ssl/cert.pem

echo -e "${GREEN}[OK]${NC} SSL certificate generated:"
echo "     nginx/ssl/cert.pem"
echo "     nginx/ssl/key.pem"
echo ""
echo -e "${YELLOW}[NOTE]${NC} This is a self-signed cert. Browsers will show a warning."
echo "       To bypass: click 'Advanced' → 'Proceed to <IP> (unsafe)'"
echo "       For production with a domain, use: ./certbot-setup.sh"
echo ""
echo -e "${BLUE}[INFO]${NC} Certificate valid for:"
echo "       https://localhost"
echo "       https://127.0.0.1"
echo "       https://${LAN_IP}"
